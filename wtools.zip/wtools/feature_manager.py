
def lineEdit_textChanged():
    pass

def manager(iface, dockwidget):
    dockwidget.lineEdit.textChanged.connect(lineEdit_textChanged)
