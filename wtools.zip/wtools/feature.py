import time

def filtrado_por_atributo(lista_features, propiedad, texto):
    resultado_filtrado = [d for d in lista_features if texto in d.get(propiedad, "").lower()]
    return resultado_filtrado

l = [
    {"name": "Marta", "edad": 22},
    {"name": "Julia", "edad": 20},
    {"name": "Martin", "edad": 29},
    {"name": "Alex", "edad": 25}
]

for i in range(10000000):
    l.append({"name": "Alex", "edad": 25})

inicio = time.time()

# Filtrar la lista de diccionarios
resultado_filtrado = [d for d in l if "ma" in d.get("name", "").lower()]


# Guardar el tiempo de finalización
fin = time.time()

# Calcular el tiempo transcurrido
tiempo_transcurrido = fin - inicio
# Imprimir el resultado
print(resultado_filtrado)
print(tiempo_transcurrido)
