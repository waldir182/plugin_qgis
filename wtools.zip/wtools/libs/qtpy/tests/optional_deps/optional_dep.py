"""Test module with an optional dependency that may be missing."""


class ExampleClass:
    pass
