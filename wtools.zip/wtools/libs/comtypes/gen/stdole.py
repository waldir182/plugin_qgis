from enum import IntFlag

import comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 as __wrapper_module__
from comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 import (
    OLE_XSIZE_CONTAINER, IDispatch, OLE_XPOS_CONTAINER,
    OLE_YSIZE_PIXELS, Color, dispid, FONTSTRIKETHROUGH, IEnumVARIANT,
    Gray, OLE_XSIZE_HIMETRIC, BSTR, OLE_XPOS_PIXELS, EXCEPINFO,
    OLE_YPOS_HIMETRIC, DISPMETHOD, Font, FONTITALIC, Library,
    IUnknown, FONTSIZE, OLE_YPOS_CONTAINER, FontEvents, HRESULT,
    _lcid, IPictureDisp, COMMETHOD, Default, StdFont,
    OLE_OPTEXCLUSIVE, OLE_ENABLEDEFAULTBOOL, GUID, FONTBOLD,
    IFontEventsDisp, OLE_CANCELBOOL, Picture, VgaColor, VARIANT_BOOL,
    FONTUNDERSCORE, Monochrome, OLE_COLOR, DISPPARAMS, _check_version,
    CoClass, OLE_YSIZE_CONTAINER, OLE_YPOS_PIXELS, IPicture,
    OLE_XPOS_HIMETRIC, typelib_path, OLE_YSIZE_HIMETRIC, IFont,
    Unchecked, FONTNAME, OLE_XSIZE_PIXELS, OLE_HANDLE, IFontDisp,
    StdPicture, DISPPROPERTY, Checked
)


class LoadPictureConstants(IntFlag):
    Default = 0
    Monochrome = 1
    VgaColor = 2
    Color = 4


class OLE_TRISTATE(IntFlag):
    Unchecked = 0
    Checked = 1
    Gray = 2


__all__ = [
    'OLE_XSIZE_CONTAINER', 'OLE_XPOS_CONTAINER', 'Default',
    'LoadPictureConstants', 'StdFont', 'OLE_OPTEXCLUSIVE',
    'OLE_YSIZE_PIXELS', 'Color', 'OLE_ENABLEDEFAULTBOOL', 'FONTBOLD',
    'IFontEventsDisp', 'OLE_CANCELBOOL', 'Picture',
    'FONTSTRIKETHROUGH', 'VgaColor', 'FONTUNDERSCORE', 'Gray',
    'OLE_XSIZE_HIMETRIC', 'Monochrome', 'OLE_COLOR', 'OLE_TRISTATE',
    'OLE_XPOS_PIXELS', 'OLE_YSIZE_CONTAINER', 'OLE_YPOS_HIMETRIC',
    'OLE_YPOS_PIXELS', 'IPicture', 'OLE_XPOS_HIMETRIC', 'Font',
    'typelib_path', 'OLE_YSIZE_HIMETRIC', 'FONTITALIC', 'Library',
    'IFont', 'Unchecked', 'FONTSIZE', 'OLE_XSIZE_PIXELS',
    'OLE_HANDLE', 'FONTNAME', 'OLE_YPOS_CONTAINER', 'IFontDisp',
    'FontEvents', 'StdPicture', 'IPictureDisp', 'Checked'
]

