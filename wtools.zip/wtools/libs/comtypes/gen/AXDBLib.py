from enum import IntFlag

import comtypes.gen._39FFAA00_8623_488F_8C53_DD3B0B7A464F_0_1_0 as __wrapper_module__
from comtypes.gen._39FFAA00_8623_488F_8C53_DD3B0B7A464F_0_1_0 import (
    acArrowDot, acShape, IAcadComparedReference,
    acAlignPntAcquisitionAutomatic, IAcadLine, acMiddleCenter,
    acCellBottomVisibility, acExtents, AcadNurbSurface,
    acSectionSubItemkNone, AcadSecurityParams, acDataRowTextHeight,
    acWhite, acEngineering, acDegrees60, acMenuFileSource,
    acAttachmentHorizontal, acDisplay, IAcadSubDMeshVertex,
    acInsertUnitsDecimeters, AcadDwfUnderlay, acR18_dxf,
    acAttachmentPointTopRight, ac2_1, acHorizontalAlignmentFit,
    acArrowOpen, acDataVertLeftVisibility, kInheritCellFormat,
    acVp3_32in_1ft, acVp1_16, acTitleRowAlignment, acFirstNormal,
    acR14_dwg, acArrowOpen90, IAcadBlocks, acFlowDirection,
    acAttachmentAllLine, acDegreesHorz, acAlwaysRightReadingAngle,
    IAcadSubEntSolidFace, acDimPrecisionFive, acHeaderHorzBottomColor,
    acLeftMask, AcadPolyline, acUnitVolume, ac1_4,
    acNoDrawingAreaShortCutMenu, IAcadSortentsTable, acViewport3Above,
    acR18_dwg, acSectionGenerationDestinationReplaceBlock,
    AcadPViewport, acDate, ac2010_Template, ac2004_dxf, ac2018_dwg,
    IAcadSectionSettings, AcadTolerance, IAcadExternalReference,
    acHorzBottom, acPrinterNeverAlert, acCellStateContentModified,
    acTextStyle, acExtendOtherEntity, ac2000_dxf, IAcadViewports,
    acDimPrecisionSix, acMenuItem, acZero, IAcadMaterials,
    AcadSectionTypeSettings, acActiveViewport, AcadSubEntSolidEdge,
    acOverSecondExtension, acLnWt009, acSectionSubItemBackLineTop,
    dispid, acInvalidGridLine, acDataRowFillNone, acVp10_1,
    acSectionSubItemSectionLineBottom, acBottomRight, acHatchObject,
    acMLine, AcadDim3PointAngular, acLnWt053, acTop,
    AcadPlotConfigurations, acCellContentColor,
    acAttachmentLinedCenter, acPenWidthUnk, acMetric, acMTextContent,
    IUnknown, acDataVertLeftLineWeight, AcadSectionSettings,
    acArrowDotSmall, acSectionStateBoundary, acNurbSurface,
    acArrowClosed, acSplineLeader, AcadText, IAcadDwfUnderlay,
    AcadSubEntSolidVertex, acDimLDecimal, AcadObject,
    acZoomScaledRelativePSpace, acVp1_8in_1ft, AcadLoftedSurface,
    VARIANT_BOOL, acFontBold, acKeyboardEntryExceptScripts,
    AcadHyperlinks, acAttachmentTopOfTop, acDimArchitectural,
    acCircle, acOTLink, acHeaderRowColor, AcadPolyfaceMesh,
    acHeaderRowFillColor, acCellStateNone, acProxyBoundingBox,
    acMergeCellStyleConvertDuplicatesToOverrides, AcadDictionary,
    IAcadLWPolyline, acStraightLeader, acLimits, IAcadLayouts,
    IAcadXline, acAttachmentMiddleOfBottom, ac2000_Template,
    acSectionGenerationSourceSelectedObjects, acDimDecimal,
    acNoneContent, acSectionState2Plane, acArrowIntegral, acLnWt040,
    acVp3_16in_1ft, acOn, acNotStacked, acScale, acDim3PointAngular,
    acPolicyNamed, IAcadTolerance, acAllViewports,
    acHeaderRowAlignment, AcadRegisteredApplication, AcadLineType,
    acDimLFractional, acCyan, IAcadDictionaries, IAcadPointCloudEx,
    acHatchLoopTypeExternal, acMoveTextNoLeader,
    acViewport2Horizontal, AcadTextStyle, acDimWindowsDesktop,
    acInsertUnitsInches, ac1_16, acSymAbove, acDataRowDataType,
    acArrowsOnly, acToolbarDockTop, AcadTableStyle, acBlockContent,
    acGroup, acRuled, acDimPrecisionThree, acCellDataType,
    acRepeatLastCommand, HRESULT, acIntensities, AcadMLeader,
    acAllCellProperties, acCellBackgroundFillNone,
    acDataHorzInsideVisibility, acDimLWindowsDesktop,
    acHeaderVertLeftLineWeight, AcadOle, IAcadDimStyles,
    IAxDbDocument, acCenterMark, acDrawContentFirst, IAcadRasterImage,
    AcadTable, acOutside, acScientific, acAlignmentBottomRight,
    AcadUCSs, acCellMarginTop, acProxyNotShow, acInsertUnitsParsecs,
    acCellStateContentLocked, acBestFit, ac270degrees,
    acParseOptionNone, acPenWidth050, AxDbDocument, acBlockCell,
    acLineSpacingStyleAtLeast, acContentLayout, AcadEllipse,
    acInsertUnitsAngstroms, acTableSelectCrossing,
    acHorizontalAlignmentAligned, acOPQHighGraphics,
    acDataHorzBottomVisibility, acCellContentTypeBlock, IDispatch,
    acDegrees180, AcadLine, acAttributeModeVerify, IAcadView,
    acAlignmentMiddle, acLineSpacingStyleExactly, acLeader,
    acReceivesShadows, acToolbarFlyout, acSCM, acR15_dxf,
    acTitleHorzBottomLineWeight, acSimpleMesh,
    acHorizontalAlignmentLeft, acBlockHexagon, AcadWipeout, acTolTop,
    AcadIdPair, acLong, acAlignPntAcquisitionShiftToAcquire,
    ac1_32in_1ft, acIntensityRainbow, acArrowOrigin2, AcadDimAngular,
    acHeaderVertRightLineWeight, acHatchStyleOuter, acTextOnly,
    ACADSECURITYPARAMS_ENCRYPT_PROPS, acDimLArchitectural,
    acHorzCellMargin, AcadMLine, acDimFractional, acObjectColor,
    acAttributeModeMultipleLine, acR15_dwg, IAcadEllipse, IAcadArc,
    AcadSubDMeshFace, acView, acCastsAndReceivesShadows,
    acHatchPatternTypeUserDefined, acDegreesAny, acPViewport,
    acGeneral, acMax, acTitleVertRightLineWeight, acDataRowAlignment,
    IAcadGroup, acLineNoArrow, acLnWt070, IAcadPoint, IAcadIdPair,
    acCellTextStyle, AcadAttribute, acAttachmentBottomLine,
    IAcadRegion, acAlignmentRight, acTolNone, acByBlock,
    IAcadDim3PointAngular, AcadSubEntSolidFace, acQuadSplinePoly,
    acIsoparms, acToolbarDockRight, acBlockImperial, acBottomLeft,
    acJIS, acAlignmentMiddleLeft, acDataRow, acLsColor, IAcad3DSolid,
    acUseMaximumPrecision, acHatchLoopTypeDerived, acMarginLeft,
    acLsLocked, acHatch, acDimAligned, acRGB, ACAD_NOUNITS,
    acDegreeMinuteSeconds, acNorm, acAlwaysCrease,
    acHatchPatternTypeCustomDefined, AcadDgnUnderlay,
    AcadDimDiametric, ac0degrees, acUpdateOptionIncludeXrefs,
    acSectionSubItemBackLineBottom, IAcadTable,
    acDataVertRightVisibility, ac1_20, IAcadGeoPositionMarker,
    IAcadSubDMeshEdge, acDemandLoadEnabledWithCopy, IAcadMaterial,
    acLeftAlignment, IAcadDimArcLength,
    acUpdateOptionOverwriteFormatModifiedAfterUpdate,
    acHorizontalAlignmentMiddle, acVp1_100, AcadPolygonMesh,
    COMMETHOD, acDemandLoadDisabled, acAttributeModePreset,
    IAcadDynamicBlockReferenceProperty, ac1_8in_1ft, IAcadSection,
    acAttributeReference, acSectionType2dSection, _check_version,
    acBackgroundColor, acSectionState2Boundary, acProxyShow,
    acPaperSpace, acSelectionSetCrossingPolygon, acLineWithArrow,
    acHorzCentered, acMtext, acCellRightGridColor, AcadPointCloud,
    acTitleRowFillNone, acHeaderVertInsideLineWeight, acBuffer,
    acModelSpace, acHide, acAttributeModeConstant,
    acUpdateOptionUpdateFullSourceRange, acHatchLoopTypePolyline,
    AcadDimension, IAcadDimRadialLarge, acUpdateOptionNone,
    acDragDisplayAutomatically, IAcadTextStyles, acTopMask,
    AcadMaterial, acDataHorzInsideColor, acTitleRowDataType,
    acArrowDefault, acDrawLeaderTailFirst, acArrowBoxFilled,
    acKeyboardRunningObjSnap, acVp1_10, IAcadText, acHatchStyleNormal,
    acInsertUnitsMiles, AcadDimAligned, acRadians, acPoint,
    IAcadSubEntSolidEdge, IAcadUCSs, acCellStateFormatLocked,
    acTitleRowFillColor, AcadBlock, acDegrees090, acDegrees90,
    acMiddleLeft, acLsPlotStyle, acTableTopToBottom,
    acSelectionSetWindow, acVerticalAlignmentBottom,
    acDataVertInsideVisibility, acViewport3Left, acCenterAlignment,
    helpstring, acLnWt035, acBottom, acDimOrdinate,
    acHatchPatternTypePreDefined, acAttachmentBottomOfTopLine,
    acFractional, acNormal, IAcadMLeader, AcadPaperSpace, acTolMiddle,
    ac3_4in_1ft, acAttachmentMiddle, acEdRepeatLastCommand, acString,
    acCenterNone, ac2018_dxf, acHorizontalAlignmentCenter,
    IAcadSection2, acSymInFront, acAttributeModeNormal,
    acCellStateLinked, IAcadLayers, acTextHeight, acTolLimits,
    AcadSubEntity, acTitleHorzInsideVisibility,
    acSectionGenerationSourceAllObjects, AcadMaterials,
    ac2004_Template, acFontBoldItalic, IAcadShape, acUnknownDataType,
    acPreDefinedGradient, ac2013_dxf, acPenWidth200, acLsLineWeight,
    acLnWt018, AcadHyperlink, acPenWidth018, acByLayer,
    acPolicyLegacyQuery, acCellContentTypeValue, AcadBlocks,
    acDataRowColor, acCastsShadows, AcadXRecord, acMarginTop,
    AcadTextStyles, acInsertUnitsDecameters, acCellAlign, acLine,
    IAcadHatch, acTolBasic, acAttributeModeLockPosition,
    IAcadUnderlay, acShadePlotAsDisplayed, IAcadSectionTypeSettings2,
    acCellStateFormatModified, ACAD_DISTANCE,
    acInsertUnitsUSSurveyFeet, acTopCenter, acDimLineWithText,
    ACAD_LTYPE, acDiagonal, acFitCurvePoly, Acad3DPolyline,
    acDimPrecisionOne, acDimEngineering, acIsolines, AcadSolid,
    ac2000_dwg, IAcadModelSpace, acRed, acVerticalAlignmentMiddle,
    acVp1_40, ac1_8, ac100_1, IAcadEntity, acColorMethodByRGB, acLock,
    AcadView, IAcadRevolvedSurface, AcadXline, IAcadMLeaderLeader,
    acCreaseByLevel, IAcadGeomapImage, acRightAlignment,
    IAcadDictionary, acPaletteBySession, acSqrtChord, acXline,
    acDataVertLeftColor, acDistance, acPolyfaceMesh,
    acIgnoreMtextFormat, acIntensityGreen,
    acHeaderVertInsideVisibility, IAcadLayerStateManager,
    ac3_16in_1ft, acHorzInside, acTableFlowLeft, ac3_32in_1ft,
    acColorMethodByLayer, acAlignmentBottomCenter, acGreen, ac1_1,
    acPenWidth025, acShadePlotWireframe, acSectionState2Slice,
    acAttachmentPointMiddleCenter, acSectionSubItemSectionLine,
    acObject, IAcadSubEntSolidVertex, AcadSpline, AcadSubDMesh,
    acMenuSeparator, IAcadDimRotated, acDataHorzTopVisibility,
    AcadBlockReference, acDrawLeaderHeadFirst, AcadMLeaderStyle,
    acAttachmentPointBottomCenter, AcadHatch, acVp1ft_1ft,
    acLsLineType, ac2007_dxf, acCellLeftVisibility, acUnitAngle,
    AcadDimRotated, acDegrees000, acObjectId, IAcadPolyfaceMesh,
    acDataRowFillColor, acTitleHorzTopColor, acInsertUnitsFeet,
    IAcadUCS, acVp1_2in_1ft, acSectionStateVolume, acInsertUnitsMils,
    acLnWt060, AcadGeomapImage, acDimRadial,
    acSectionSubItemSectionLineTop, acDegrees45, IAcadLineType,
    acDataHorzInsideLineWeight, acSelectionSetAll, IAcadLineTypes,
    acPlotOrientationLandscape, acPreserveMtextFormat, acLnWt090,
    acPdfUnderlay, acAlignmentFit, ac2013_Template, acInVisibleLeader,
    acViewport3Right, AcadRegisteredApplications, ac3dSolid,
    AcadLineTypes, acBottomToTop, acAlignmentProperty,
    acVp1and1_2in_1ft, acSelectionSetCrossing, IAcadSummaryInfo,
    acDimRadialLarge, acPenWidth140, acLnWt106, acCubicSpline3DPoly,
    ac2010_dwg, acNoOverrides, acTitleRow, acR13_dwg, acDimRotated,
    acElevation, AcadPoint, acHeaderVertInsideColor,
    acInsertUnitsMicroinches, acUseDefaultDrawingAreaShortCutMenu,
    acArrowClosedBlank,
    acUpdateOptionOverwriteContentModifiedAfterUpdate,
    IAcadPolygonMesh, AcadComparedReference, IAcadMInsertBlock,
    acTextCell, ac2007_Template, acBezierSurfaceMesh, acTolDeviation,
    GUID, acPreferenceClassic, acTrace, acPartialPreview,
    AcadDimArcLength, AcadSubDMeshVertex, acLastNormal,
    acExternalReference, ac8_1, acColorMethodForeground,
    IAcadPointCloudEx2, acBlockCircle,
    acCellContentLayoutStackedHorizontal, ac1_128in_1ft, acR12_dxf,
    IAcadHyperlink, IAxDbDocumentEvents, acDataHorzTopLineWeight,
    acInsertUnitsUnitless, acSelectionSetLast, acUpdateSourceFromData,
    ac1_5, acAttribute, acDisplayDCS, acHeight, acOverFirstExtension,
    acSmooth, acTitleHorzTopLineWeight, AcadLayout, AcadDimRadial,
    acAttachmentPointTopCenter, acPrinterAlertOnce, acBaseMenuGroup,
    acContentProperties, acEnableSCMOptions, acUseDraftAngles,
    acAlignmentBottomLeft, acLsOn, acHorzTop, acViewport2Vertical,
    acSolid, acPartialMenuGroup, acTolerance, IAcadLeader,
    acEnableBackgroundColor, acTrue, acSectionSubItemVerticalLineTop,
    acSectionSubItemBackLine, ac2018_Template, acQuadSpline3DPoly,
    acCellBackgroundColor, ac1_10, acAttachmentPointBottomLeft,
    acR13_dxf, acTurns, kFormatOptionNone, AcadSection, ac3dPolyline,
    acVp1_64in_1ft, acPaperSpaceDCS, acIgnoreShadows, _lcid,
    ac180degrees, acArc, acAttachmentPointMiddleRight, acScanColor,
    acAutoScale, acVp3_8in_1ft, IAcadPViewport, acDataVertInsideColor,
    ac1_16in_1ft, acHeaderHorzInsideLineWeight, IAcadDimension,
    acVp1in_1ft, acDemanLoadDisable, acUpdateDataFromSource,
    ac3in_1ft, CoClass, acArrowArchTick, acHeaderHorzTopLineWeight,
    acHeaderRowDataType, AcadEntity, acAllNormal, AcadArc,
    acIntensityBlue, acRegion, acHorizontalAlignmentRight,
    IAcadGroups, acInsertAngle, acVerticalAlignmentTop, acSpline,
    acIntersection, acLnWt013, acDimPrecisionFour, IAcadShadowDisplay,
    acShow, acAttachmentPointBottomRight, IAcadSectionTypeSettings,
    AcadDimStyles, AcadAcCmColor, acInsertUnitsHectometers, acPixels,
    acDegrees30, IAcadHelix, AcadCircle, acVertCellMargin,
    acToolbarDockBottom, acBottomCenter, acLnWtByLayer, acDegrees15,
    acInsertUnitsMicrons, acHeaderHorzInsideVisibility,
    acTextFlagUpsideDown, IAcad3DPolyline, acCellContentTypeField,
    acLsAll, acSimple3DPoly, acTitleSuppressed, acSetDefaultFormat,
    acTextAndArrows, acLeftToRight, acIntensityGrayscale, AcadShape,
    IAcadSubDMesh, acLnWt100, acTopToBottom,
    acHeaderVertRightVisibility, acPoint3d, acTrueColor,
    acInsertUnitsMeters, acNoUnits, acEdSCM, ACAD_ANGLE, acOCS,
    acContentColor, acDegreesUnknown, IAcadNurbSurface, acVp2_1,
    acArrowOblique, IAcadRegisteredApplications, IAcadOle,
    acFontItalic, ac1ft_1ft, acLnWt211, IAcadLoftedSurface,
    acCellContentLayoutStackedVertical, acVp6in_1ft, acExtendNone,
    acText, acVp1_1, acShadePlotRendered, AcadViewport, acMergeAll,
    acUCS, AcadExternalReference, IAcadAttributeReference,
    ACADSECURITYPARAMS_SIGN_DATA, acFlowDirBtoT, IAcadPolyline, acCCW,
    acDataVertRightLineWeight, acSelectionSetFence, acLnWt200,
    acUnitless, IAcadXRecord, acAlignmentCenter, acDegrees, acAngular,
    acCenterLine, acZoomScaledAbsolute, acArrowDatumBlank,
    AcadSubDMeshEdge, acDimPrecisionTwo, acNormals,
    acMenuFileCompiled, acVp3_4in_1ft, acUnknownCell, BSTR,
    acDataTypeAndFormat, IAcadSpline, acMenuSubMenu, acMin,
    acAttributeModeInvisible, acTitleVertRightColor, acVp1_5,
    acDemandLoadEnabled, acCellMarginLeft, acPolicyLegacy,
    acHeaderRowFillNone, acSectionGenerationDestinationFile,
    IAcadSubEntity, acMiddleRight, acGridLineStyleSingle, acVp1_2,
    acDegrees270, IAcadHyperlinks, acHeaderVertRightColor, acEnglish,
    IAcadSweptSurface, acPenWidth100, acUniformParam, acLnWt158,
    acAttachmentVertical, acAlignmentMiddleCenter,
    acSecondExtensionLine, acTitleVertInsideLineWeight,
    acCellStateFormatReadOnly, acTitleRowTextStyle, ac1_30,
    acCellMarginBottom, acHeaderRowTextHeight, IAcad3DFace,
    acUnitArea, IAcadViewport, IAcadDatabase, acOQLineArt,
    acSplineWithArrow, acPenWidth070, acLnWtByLwDefault, VARIANT,
    acLnWt030, acInsertUnitsPrompt, acHeaderHorzBottomVisibility,
    acCubicSurfaceMesh, AcadLeader, acPoint2d, acR15_Template,
    acCellRightVisibility, IAcadBlock, acShadePlotHidden,
    acSelectionSetWindowPolygon, acBlockReference,
    acDragDisplayOnRequest, acMLeader, ac1_2in_1ft,
    IAcadSectionManager, AcadMLeaderLeader, acMillimeters,
    acInsertUnitsUSSurveyMile, AcadSweptSurface,
    acTitleVertInsideColor, acCellContentTypeUnknown, IAcadSurface,
    AcadModelSpace, AcadDictionaries, acAlignmentMiddleRight,
    acVp1_30, AcadSortentsTable, acPreferenceCustom, IAcadAttribute,
    acBlockTriangle, acArrowSmall, acViewport4, IAcadDimDiametric,
    acTolBottom, acUserDefinedGradient, acTableFlowRight, AcadLayouts,
    acEnableSCM, IAcadMText, acTitleVertLeftLineWeight, acIntensity,
    acNoneCrease, IAcadPlaneSurface, acArrowNone, IAcadSolid, ac1_100,
    acClassification, IAcadSubEntSolidNode, AcadMInsertBlock, acChord,
    acToolbarButton, AcadViewports, acVpCustomScale,
    acToolbarFloating, AcadRasterImage, acTitleRowColor, ac1_4in_1ft,
    acDimLEngineering, acTitleHorzBottomVisibility, AcadLWPolyline,
    IAcadLayer, acLnWt025, AcadMText, acWindow, acPolicyLegacyLegacy,
    IAcadPlotConfiguration, acSectionTypeLiveSection,
    acColorMethodByBlock, acOQHighPhoto, acTextFlagBackward,
    acViewport3Below, ac1_2, acCellMarginVertSpacing, IAcadDimAligned,
    acInsertUnitsUSSurveyYard, AcadUCS, acTopRight,
    acGridLineStyleDouble, AcadPointCloudEx, acIntensityRed,
    acMergeCellStyleOverwriteDuplicates, AcadSectionManager, acGrads,
    acHeaderHorzBottomLineWeight, acVp8_1, acSimplePoly,
    acCellMarginRight, acDataRowTextStyle, acDataHorzBottomLineWeight,
    acFalse, acSubtraction, acToolbarSeparator, IAcadDimRadial,
    AcadDatabase, acSymNone, acVertCentered, acRightMask,
    acPlotOrientationPortrait, acDimPrecisionZero, acInches,
    IAcadPaperSpace, acRaster, acDrawLeaderFirst,
    acAttachmentMiddleOfTop, acDragDoNotDisplay,
    acCellBottomGridLineWeight, acTitleHorzBottomColor, AcadRay,
    acViewport3Horizontal, acQuadSurfaceMesh, AcadPdfUnderlay,
    acDemandLoadOnObjectDetect, acBlockUserDefined, IAcadRay,
    acViewport3Vertical, acNative, acRightToLeft, acHorizontal,
    acCellTextHeight, acSubDMesh, IAcadWipeout, acHeaderRow,
    acTableSelectWindow, ac3dFace, acPrinterNeverAlertLogOnce, acArea,
    acUnknown, AcadPlaneSurface, acEndsNormal, ac90degrees, Library,
    acArrowDotBlank, acZoomScaledRelative, ACAD_NULL,
    acDimFractionalStacked, acRay, acDimArchitecturalStacked,
    acHeaderHorzTopColor, acInsertUnitsCentimeters, acBottomMask,
    ac10_1, acMergeCellStyleCopyDuplicates, acPenWidth035,
    acLsNewViewport, acSectionType3dSection, IAcadDimOrdinate,
    acLnWt015, acUniform, AcadGroups, acMarginRight,
    acDataVertRightColor, acCellRightGridLineWeight,
    acCellBottomGridColor, acArrowUserDefined, ac1_50,
    IAcadTableStyle, IAcadPlotConfigurations, acVp1_20, acDgnUnderlay,
    acHatchLoopTypeTextbox, acVp1_50, acLnWt140, AcadTrace,
    Acad3DSolid, acOTStatic, acLnWt005, IAcadLayout,
    acHeaderHorzTopVisibility, acAlignmentTopRight, acOQGraphics,
    acDimPrecisionEight, acEllipse, acTitleRowTextHeight, ac2007_dwg,
    acArchitectural, AcadDatabasePreferences, acVp1_4,
    IAcadObjectEvents, acAlignmentAligned, AcadAttributeReference,
    ac2010_dxf, acR18_Template, acLnWtByBlock,
    acMergeCellStyleIgnoreNewStyles, acVp1_32in_1ft, IAcadTextStyle,
    acForExpression, acTitleHorzTopVisibility, ac4_1, acDimScientific,
    acCellContentLayoutFlow, acTitleVertRightVisibility,
    acHatchStyleIgnore, acPolicyLegacyDefault, acArrowDatumFilled,
    acColorMethodByACI, acVp1_16in_1ft, acLsPlot,
    IAcadRegisteredApplication, acInsertUnitsNanometers,
    acHatchLoopTypeDefault, acRotation, acFontRegular, acUnder,
    acAttachmentPointMiddleLeft, AcadRevolvedSurface,
    acOPQLowGraphics, acVp1_8, acArrowBoxBlank,
    acInsertUnitsGigameters, AcadDimOrdinate, acDimAngular, ac1_40,
    acLayout, acEnter, acVertRight, acArrowOrigin,
    acCellTopVisibility, AcadViews, acCustomParameterization,
    ac6in_1ft, IAcadBlockReference, ACADSECURITYPARAMS_ENCRYPT_DATA,
    acTitleVertInsideVisibility, acCW, acTurnHeight,
    acAttachmentBottomOfTop, acPenWidth013, acTopLeft,
    acInsertUnitsAstronomicalUnits, acTitleHorzInsideColor,
    acBitProperties, acDimPrecisionSeven, acVpScaleToFit, AcadRegion,
    acAttachmentPointTopLeft, IAcadViews, acControlVertices, acDouble,
    acOPQMonochrome, acVp4_1, acLsNone, acGradientObject,
    kCellOptionNone, ACAD_POINT, acUnknownRow, AcadLayer, acOQPhoto,
    acMagenta, IAcadObject, acTolSymmetrical, acDimDiametric,
    acUnitDistance, acDwfUnderlay, LONG_PTR, acTitleVertLeftColor,
    AcadSummaryInfo, acSectionSubItemVerticalLineBottom,
    AcadLayerStateManager, AcadLayers, AcadHelix, acLsFrozen,
    acPolyline, acExtendBoth, ac1in_1ft, Acad3DFace,
    AcadGeoPositionMarker, AcadPlotConfiguration, acArrowOpen30,
    acDataVertInsideLineWeight, acToolbarDockLeft, IAcadDimStyle,
    acVertInside, acHorizontalAngle, acInsertUnitsUSSurveyInch,
    IAcadSubDMeshFace, IAcadAcCmColor, acMInsertBlock,
    acTableBottomToTop, AcadSubEntSolidNode, IAcadDimAngular,
    acMergeCellStyleNone, acFit, acCellStateContentReadOnly, acBlue,
    acHeaderVertLeftColor, acCubicSplinePoly, acConnectExtents,
    IAcadMLine, acLnWt000, IAcadCircle, acForEditing,
    acInsertUnitsKilometers, IAcadTrace, acCellMarginHorzSpacing,
    acPolylineLight, acBlockSlot, ACADSECURITYPARAMS_ADD_TIMESTAMP,
    ACADSECURITYPARAMS_ALGID_RC4, acCellLeftGridColor, ac3_8in_1ft,
    acKeyboardEntry, acPolymesh, acLnWt050, acHeaderHorzInsideColor,
    acExtendThisEntity, AcadDimStyle, ac2013_dwg, AcadSurface, acOff,
    acHeaderSuppressed, acDefaultUnits, acInvalidCellProperty,
    acAlignmentTopLeft, acSectionStatePlane, acDataType, acYellow,
    ACAD_LAYER, acCellTopGridColor, acAny, acTableFlowDownOrUp,
    ac2004_dwg, acAlignmentLeft, acAlignmentTopCenter, acByColor,
    acTable, acPolicyNewLegacy, acBlockBox, acLnWt120,
    IAcadPointCloud, acVp1_128in_1ft, acAbove, AcadExtrudedSurface,
    acResbuf, acVp3in_1ft, acSectionState2Volume, acDecimal,
    acInsertUnitsAutoAssign, acOTEmbedded,
    acVerticalAlignmentBaseline, acIntensityEditableFlag, acLnWt080,
    IAcadExtrudedSurface, acMarginBottom, acVp100_1,
    IAcadSecurityParams, AcadDimRadialLarge, acVertLeft, acOQText,
    acCellLeftGridLineWeight, acDimLScientific, acSplineNoArrow,
    acSelectionSetPrevious, acPrinterAlwaysAlert, acConnectBase,
    acLnWt020, acFirstExtensionLine, acMoveTextAddLeader,
    acToolbarControl, acCellTopGridLineWeight, acApplied,
    acPolicyNewDefault, acDataHorzBottomColor, acDimArcLength,
    acVp1_4in_1ft, acHeaderVertLeftVisibility, acR14_dxf,
    acInsertUnitsYards, acHeaderRowTextStyle,
    acAttachmentBottomOfBottom, acInsertUnitsLightYears,
    acFullPreview, acInsertUnitsMillimeters, acByStyle, acUnion,
    ac1_64in_1ft, acPaletteByDrawing, acWorld, typelib_path,
    acAttachmentCenter, acDemandLoadCmdInvoke,
    acTitleHorzInsideLineWeight, acDataFormat, acScaleToFit,
    acTitleVertLeftVisibility, IAcadDatabasePreferences,
    AcadDynamicBlockReferenceProperty, AcadGroup, acDataHorzTopColor,
    IAcadMLeaderStyle, acSectionGenerationDestinationNewBlock
)


class AcExtendOption(IntFlag):
    acExtendNone = 0
    acExtendThisEntity = 1
    acExtendOtherEntity = 2
    acExtendBoth = 3


class AcLineWeight(IntFlag):
    acLnWt000 = 0
    acLnWt005 = 5
    acLnWt009 = 9
    acLnWt013 = 13
    acLnWt015 = 15
    acLnWt018 = 18
    acLnWt020 = 20
    acLnWt025 = 25
    acLnWt030 = 30
    acLnWt035 = 35
    acLnWt040 = 40
    acLnWt050 = 50
    acLnWt053 = 53
    acLnWt060 = 60
    acLnWt070 = 70
    acLnWt080 = 80
    acLnWt090 = 90
    acLnWt100 = 100
    acLnWt106 = 106
    acLnWt120 = 120
    acLnWt140 = 140
    acLnWt158 = 158
    acLnWt200 = 200
    acLnWt211 = 211
    acLnWtByLayer = -1
    acLnWtByBlock = -2
    acLnWtByLwDefault = -3


class AcColor(IntFlag):
    acByBlock = 0
    acRed = 1
    acYellow = 2
    acGreen = 3
    acCyan = 4
    acBlue = 5
    acMagenta = 6
    acWhite = 7
    acByLayer = 256


class AcHorizontalAlignment(IntFlag):
    acHorizontalAlignmentLeft = 0
    acHorizontalAlignmentCenter = 1
    acHorizontalAlignmentRight = 2
    acHorizontalAlignmentAligned = 3
    acHorizontalAlignmentMiddle = 4
    acHorizontalAlignmentFit = 5


class AcVerticalAlignment(IntFlag):
    acVerticalAlignmentBaseline = 0
    acVerticalAlignmentBottom = 1
    acVerticalAlignmentMiddle = 2
    acVerticalAlignmentTop = 3


class AcAlignment(IntFlag):
    acAlignmentLeft = 0
    acAlignmentCenter = 1
    acAlignmentRight = 2
    acAlignmentAligned = 3
    acAlignmentMiddle = 4
    acAlignmentFit = 5
    acAlignmentTopLeft = 6
    acAlignmentTopCenter = 7
    acAlignmentTopRight = 8
    acAlignmentMiddleLeft = 9
    acAlignmentMiddleCenter = 10
    acAlignmentMiddleRight = 11
    acAlignmentBottomLeft = 12
    acAlignmentBottomCenter = 13
    acAlignmentBottomRight = 14


class AcDrawingDirection(IntFlag):
    acLeftToRight = 1
    acRightToLeft = 2
    acTopToBottom = 3
    acBottomToTop = 4
    acByStyle = 5


class AcPlotPolicyForNewDwgs(IntFlag):
    acPolicyNewDefault = 0
    acPolicyNewLegacy = 1


class AcPlotPolicyForLegacyDwgs(IntFlag):
    acPolicyLegacyDefault = 0
    acPolicyLegacyQuery = 1
    acPolicyLegacyLegacy = 2


class AcActiveSpace(IntFlag):
    acPaperSpace = 0
    acModelSpace = 1


class AcOleQuality(IntFlag):
    acOQLineArt = 0
    acOQText = 1
    acOQGraphics = 2
    acOQPhoto = 3
    acOQHighPhoto = 4


class AcKeyboardAccelerator(IntFlag):
    acPreferenceClassic = 0
    acPreferenceCustom = 1


class AcDimVerticalJustification(IntFlag):
    acVertCentered = 0
    acAbove = 1
    acOutside = 2
    acJIS = 3
    acUnder = 4


class AcDimPrecision(IntFlag):
    acDimPrecisionZero = 0
    acDimPrecisionOne = 1
    acDimPrecisionTwo = 2
    acDimPrecisionThree = 3
    acDimPrecisionFour = 4
    acDimPrecisionFive = 5
    acDimPrecisionSix = 6
    acDimPrecisionSeven = 7
    acDimPrecisionEight = 8


class AcDimTextMovement(IntFlag):
    acDimLineWithText = 0
    acMoveTextAddLeader = 1
    acMoveTextNoLeader = 2


class AcDimToleranceMethod(IntFlag):
    acTolNone = 0
    acTolSymmetrical = 1
    acTolDeviation = 2
    acTolLimits = 3
    acTolBasic = 4


class AcDimToleranceJustify(IntFlag):
    acTolBottom = 0
    acTolMiddle = 1
    acTolTop = 2


class AcDimUnits(IntFlag):
    acDimScientific = 1
    acDimDecimal = 2
    acDimEngineering = 3
    acDimArchitecturalStacked = 4
    acDimFractionalStacked = 5
    acDimArchitectural = 6
    acDimFractional = 7
    acDimWindowsDesktop = 8


class AcDimCenterType(IntFlag):
    acCenterMark = 0
    acCenterLine = 1
    acCenterNone = 2


class AcDimFractionType(IntFlag):
    acHorizontal = 0
    acDiagonal = 1
    acNotStacked = 2


class AcDimFit(IntFlag):
    acTextAndArrows = 0
    acArrowsOnly = 1
    acTextOnly = 2
    acBestFit = 3


class AcDimLUnits(IntFlag):
    acDimLScientific = 1
    acDimLDecimal = 2
    acDimLEngineering = 3
    acDimLArchitectural = 4
    acDimLFractional = 5
    acDimLWindowsDesktop = 6


class AcDimArrowheadType(IntFlag):
    acArrowDefault = 0
    acArrowClosedBlank = 1
    acArrowClosed = 2
    acArrowDot = 3
    acArrowArchTick = 4
    acArrowOblique = 5
    acArrowOpen = 6
    acArrowOrigin = 7
    acArrowOrigin2 = 8
    acArrowOpen90 = 9
    acArrowOpen30 = 10
    acArrowDotSmall = 11
    acArrowDotBlank = 12
    acArrowSmall = 13
    acArrowBoxBlank = 14
    acArrowBoxFilled = 15
    acArrowDatumBlank = 16
    acArrowDatumFilled = 17
    acArrowIntegral = 18
    acArrowNone = 19
    acArrowUserDefined = 20


class AcSectionType(IntFlag):
    acSectionTypeLiveSection = 1
    acSectionType2dSection = 2
    acSectionType3dSection = 4


class AcValueDataType(IntFlag):
    acUnknownDataType = 0
    acLong = 1
    acDouble = 2
    acString = 4
    acDate = 8
    acPoint2d = 16
    acPoint3d = 32
    acObjectId = 64
    acBuffer = 128
    acResbuf = 256
    acGeneral = 512


class AcPlotOrientation(IntFlag):
    acPlotOrientationPortrait = 0
    acPlotOrientationLandscape = 1


class AcLoadPalette(IntFlag):
    acPaletteByDrawing = 0
    acPaletteBySession = 1


class AcRegenType(IntFlag):
    acActiveViewport = 0
    acAllViewports = 1


class AcInsertUnits(IntFlag):
    acInsertUnitsUnitless = 0
    acInsertUnitsInches = 1
    acInsertUnitsFeet = 2
    acInsertUnitsMiles = 3
    acInsertUnitsMillimeters = 4
    acInsertUnitsCentimeters = 5
    acInsertUnitsMeters = 6
    acInsertUnitsKilometers = 7
    acInsertUnitsMicroinches = 8
    acInsertUnitsMils = 9
    acInsertUnitsYards = 10
    acInsertUnitsAngstroms = 11
    acInsertUnitsNanometers = 12
    acInsertUnitsMicrons = 13
    acInsertUnitsDecimeters = 14
    acInsertUnitsDecameters = 15
    acInsertUnitsHectometers = 16
    acInsertUnitsGigameters = 17
    acInsertUnitsAstronomicalUnits = 18
    acInsertUnitsLightYears = 19
    acInsertUnitsParsecs = 20
    acInsertUnitsUSSurveyFeet = 21
    acInsertUnitsUSSurveyInch = 22
    acInsertUnitsUSSurveyYard = 23
    acInsertUnitsUSSurveyMile = 24


class AcRowType(IntFlag):
    acUnknownRow = 0
    acDataRow = 1
    acTitleRow = 2
    acHeaderRow = 4


class AcPolymeshType(IntFlag):
    acSimpleMesh = 0
    acQuadSurfaceMesh = 5
    acCubicSurfaceMesh = 6
    acBezierSurfaceMesh = 8


class AcSectionGeneration(IntFlag):
    acSectionGenerationSourceAllObjects = 1
    acSectionGenerationSourceSelectedObjects = 2
    acSectionGenerationDestinationNewBlock = 16
    acSectionGenerationDestinationReplaceBlock = 32
    acSectionGenerationDestinationFile = 64


class AcPatternType(IntFlag):
    acHatchPatternTypeUserDefined = 0
    acHatchPatternTypePreDefined = 1
    acHatchPatternTypeCustomDefined = 2


class AcPlotPaperUnits(IntFlag):
    acInches = 0
    acMillimeters = 1
    acPixels = 2


class AcPlotRotation(IntFlag):
    ac0degrees = 0
    ac90degrees = 1
    ac180degrees = 2
    ac270degrees = 3


class AcPlotType(IntFlag):
    acDisplay = 0
    acExtents = 1
    acLimits = 2
    acView = 3
    acWindow = 4
    acLayout = 5


class AcPlotScale(IntFlag):
    acScaleToFit = 0
    ac1_128in_1ft = 1
    ac1_64in_1ft = 2
    ac1_32in_1ft = 3
    ac1_16in_1ft = 4
    ac3_32in_1ft = 5
    ac1_8in_1ft = 6
    ac3_16in_1ft = 7
    ac1_4in_1ft = 8
    ac3_8in_1ft = 9
    ac1_2in_1ft = 10
    ac3_4in_1ft = 11
    ac1in_1ft = 12
    ac3in_1ft = 13
    ac6in_1ft = 14
    ac1ft_1ft = 15
    ac1_1 = 16
    ac1_2 = 17
    ac1_4 = 18
    ac1_5 = 19
    ac1_8 = 20
    ac1_10 = 21
    ac1_16 = 22
    ac1_20 = 23
    ac1_30 = 24
    ac1_40 = 25
    ac1_50 = 26
    ac1_100 = 27
    ac2_1 = 28
    ac4_1 = 29
    ac8_1 = 30
    ac10_1 = 31
    ac100_1 = 32


class AcTableDirection(IntFlag):
    acTableTopToBottom = 0
    acTableBottomToTop = 1


class AcCellAlignment(IntFlag):
    acTopLeft = 1
    acTopCenter = 2
    acTopRight = 3
    acMiddleLeft = 4
    acMiddleCenter = 5
    acMiddleRight = 6
    acBottomLeft = 7
    acBottomCenter = 8
    acBottomRight = 9


class AcGridLineType(IntFlag):
    acInvalidGridLine = 0
    acHorzTop = 1
    acHorzInside = 2
    acHorzBottom = 4
    acVertLeft = 8
    acVertInside = 16
    acVertRight = 32


class AcValueUnitType(IntFlag):
    acUnitless = 0
    acUnitDistance = 1
    acUnitAngle = 2
    acUnitArea = 4
    acUnitVolume = 8


class AcMergeCellStyleOption(IntFlag):
    acMergeCellStyleNone = 0
    acMergeCellStyleCopyDuplicates = 1
    acMergeCellStyleOverwriteDuplicates = 2
    acMergeCellStyleConvertDuplicatesToOverrides = 4
    acMergeCellStyleIgnoreNewStyles = 8


class AcZoomScaleType(IntFlag):
    acZoomScaledAbsolute = 0
    acZoomScaledRelative = 1
    acZoomScaledRelativePSpace = 2


class AcShadowDisplayType(IntFlag):
    acCastsAndReceivesShadows = 0
    acCastsShadows = 1
    acReceivesShadows = 2
    acIgnoreShadows = 3


class AcAttachmentPoint(IntFlag):
    acAttachmentPointTopLeft = 1
    acAttachmentPointTopCenter = 2
    acAttachmentPointTopRight = 3
    acAttachmentPointMiddleLeft = 4
    acAttachmentPointMiddleCenter = 5
    acAttachmentPointMiddleRight = 6
    acAttachmentPointBottomLeft = 7
    acAttachmentPointBottomCenter = 8
    acAttachmentPointBottomRight = 9


class AcXRefDemandLoad(IntFlag):
    acDemandLoadDisabled = 0
    acDemandLoadEnabled = 1
    acDemandLoadEnabledWithCopy = 2


class AcDragDisplayMode(IntFlag):
    acDragDoNotDisplay = 0
    acDragDisplayOnRequest = 1
    acDragDisplayAutomatically = 2


class AcMeasurementUnits(IntFlag):
    acEnglish = 0
    acMetric = 1


class AcARXDemandLoad(IntFlag):
    acDemanLoadDisable = 0
    acDemandLoadOnObjectDetect = 1
    acDemandLoadCmdInvoke = 2


class AcGradientPatternType(IntFlag):
    acPreDefinedGradient = 0
    acUserDefinedGradient = 1


class AcHatchObjectType(IntFlag):
    acHatchObject = 0
    acGradientObject = 1


class AcTextGenerationFlag(IntFlag):
    acTextFlagBackward = 2
    acTextFlagUpsideDown = 4


class AcTextFontStyle(IntFlag):
    acFontRegular = 0
    acFontItalic = 1
    acFontBold = 2
    acFontBoldItalic = 3


class AcSelect(IntFlag):
    acSelectionSetWindow = 0
    acSelectionSetCrossing = 1
    acSelectionSetFence = 2
    acSelectionSetPrevious = 3
    acSelectionSetLast = 4
    acSelectionSetAll = 5
    acSelectionSetWindowPolygon = 6
    acSelectionSetCrossingPolygon = 7


class AcSectionState(IntFlag):
    acSectionStatePlane = 1
    acSectionStateBoundary = 2
    acSectionStateVolume = 4


class AcSectionSubItem(IntFlag):
    acSectionSubItemkNone = 0
    acSectionSubItemSectionLine = 1
    acSectionSubItemSectionLineTop = 2
    acSectionSubItemSectionLineBottom = 4
    acSectionSubItemBackLine = 8
    acSectionSubItemBackLineTop = 16
    acSectionSubItemBackLineBottom = 32
    acSectionSubItemVerticalLineTop = 64
    acSectionSubItemVerticalLineBottom = 128


class AcSectionState2(IntFlag):
    acSectionState2Plane = 1
    acSectionState2Slice = 2
    acSectionState2Boundary = 4
    acSectionState2Volume = 8


class AcBooleanType(IntFlag):
    acUnion = 0
    acIntersection = 1
    acSubtraction = 2


class AcWireframeType(IntFlag):
    acIsolines = 0
    acIsoparms = 1


class AcCellProperty(IntFlag):
    acInvalidCellProperty = 0
    acLock = 1
    acDataType = 2
    acDataFormat = 4
    acRotation = 8
    acScale = 16
    acAlignmentProperty = 32
    acContentColor = 64
    acBackgroundColor = 128
    acTextStyle = 256
    acTextHeight = 512
    acMarginLeft = 1024
    acMarginTop = 2048
    acMarginRight = 4096
    acMarginBottom = 8192
    acEnableBackgroundColor = 16384
    acAutoScale = 32768
    acMergeAll = 65536
    acFlowDirBtoT = 131072
    acContentLayout = 262144
    acDataTypeAndFormat = 6
    acContentProperties = 33662
    acBitProperties = 245760
    acAllCellProperties = 524287


class AcAngleUnits(IntFlag):
    acDegrees = 0
    acDegreeMinuteSeconds = 1
    acGrads = 2
    acRadians = 3


class AcDimHorizontalJustification(IntFlag):
    acHorzCentered = 0
    acFirstExtensionLine = 1
    acSecondExtensionLine = 2
    acOverFirstExtension = 3
    acOverSecondExtension = 4


class AcUnderlayLayerOverrideType(IntFlag):
    acNoOverrides = 0
    acApplied = 1


class AcSplineKnotParameterizationType(IntFlag):
    acChord = 0
    acSqrtChord = 1
    acUniformParam = 2
    acCustomParameterization = 15


class AcSplineFrameType(IntFlag):
    acShow = 0
    acHide = 1


class AcSplineMethodType(IntFlag):
    acFit = 0
    acControlVertices = 1


class AcCellType(IntFlag):
    acUnknownCell = 0
    acTextCell = 1
    acBlockCell = 2


class AcRotationAngle(IntFlag):
    acDegreesUnknown = -1
    acDegrees000 = 0
    acDegrees090 = 1
    acDegrees180 = 2
    acDegrees270 = 3


class AcCellEdgeMask(IntFlag):
    acTopMask = 1
    acRightMask = 2
    acBottomMask = 4
    acLeftMask = 8


class AcSelectType(IntFlag):
    acTableSelectWindow = 1
    acTableSelectCrossing = 2


class AcFormatOption(IntFlag):
    kFormatOptionNone = 0
    acForEditing = 1
    acForExpression = 2
    acUseMaximumPrecision = 4
    acIgnoreMtextFormat = 8


class AcParseOption(IntFlag):
    acParseOptionNone = 0
    acSetDefaultFormat = 1
    acPreserveMtextFormat = 2


class AcCellOption(IntFlag):
    kCellOptionNone = 0
    kInheritCellFormat = 1


class AcCellContentType(IntFlag):
    acCellContentTypeUnknown = 0
    acCellContentTypeValue = 1
    acCellContentTypeField = 2
    acCellContentTypeBlock = 4


class AcCellMargin(IntFlag):
    acCellMarginTop = 1
    acCellMarginLeft = 2
    acCellMarginBottom = 4
    acCellMarginRight = 8
    acCellMarginHorzSpacing = 16
    acCellMarginVertSpacing = 32


class AcCellContentLayout(IntFlag):
    acCellContentLayoutFlow = 1
    acCellContentLayoutStackedHorizontal = 2
    acCellContentLayoutStackedVertical = 4


class AcGridLineStyle(IntFlag):
    acGridLineStyleSingle = 1
    acGridLineStyleDouble = 2


class AcCellState(IntFlag):
    acCellStateNone = 0
    acCellStateContentLocked = 1
    acCellStateContentReadOnly = 2
    acCellStateFormatLocked = 4
    acCellStateFormatReadOnly = 8
    acCellStateLinked = 16
    acCellStateContentModified = 32
    acCellStateFormatModified = 64


class AcTableFlowDirection(IntFlag):
    acTableFlowRight = 1
    acTableFlowDownOrUp = 2
    acTableFlowLeft = 4


class AcHelixTwistType(IntFlag):
    acCCW = 0
    acCW = 1


class AcUnits(IntFlag):
    acDefaultUnits = -1
    acScientific = 1
    acDecimal = 2
    acEngineering = 3
    acArchitectural = 4
    acFractional = 5


class AcLoftedSurfaceNormalType(IntFlag):
    acRuled = 0
    acSmooth = 1
    acFirstNormal = 2
    acLastNormal = 3
    acEndsNormal = 4
    acAllNormal = 5
    acUseDraftAngles = 6


class AcCoordinateSystem(IntFlag):
    acWorld = 0
    acUCS = 1
    acDisplayDCS = 2
    acPaperSpaceDCS = 3
    acOCS = 4


class AcProxyImage(IntFlag):
    acProxyNotShow = 0
    acProxyShow = 1
    acProxyBoundingBox = 2


class AcadSecurityParamsConstants(IntFlag):
    ACADSECURITYPARAMS_ALGID_RC4 = 26625


class AcadSecurityParamsType(IntFlag):
    ACADSECURITYPARAMS_ENCRYPT_DATA = 1
    ACADSECURITYPARAMS_ENCRYPT_PROPS = 2
    ACADSECURITYPARAMS_SIGN_DATA = 16
    ACADSECURITYPARAMS_ADD_TIMESTAMP = 32


class AcISOPenWidth(IntFlag):
    acPenWidth013 = 13
    acPenWidth018 = 18
    acPenWidth025 = 25
    acPenWidth035 = 35
    acPenWidth050 = 50
    acPenWidth070 = 70
    acPenWidth100 = 100
    acPenWidth140 = 140
    acPenWidth200 = 200
    acPenWidthUnk = -1


class AcToolbarItemType(IntFlag):
    acToolbarButton = 0
    acToolbarSeparator = 1
    acToolbarControl = 2
    acToolbarFlyout = 3


class AcLineSpacingStyle(IntFlag):
    acLineSpacingStyleAtLeast = 1
    acLineSpacingStyleExactly = 2


class AcDimArcLengthSymbol(IntFlag):
    acSymInFront = 0
    acSymAbove = 1
    acSymNone = 2


class AcLayerStateMask(IntFlag):
    acLsNone = 0
    acLsOn = 1
    acLsFrozen = 2
    acLsLocked = 4
    acLsPlot = 8
    acLsNewViewport = 16
    acLsColor = 32
    acLsLineType = 64
    acLsLineWeight = 128
    acLsPlotStyle = 256
    acLsAll = 65535


class AcPrinterSpoolAlert(IntFlag):
    acPrinterAlwaysAlert = 0
    acPrinterAlertOnce = 1
    acPrinterNeverAlertLogOnce = 2
    acPrinterNeverAlert = 3


class AcHelixConstrainType(IntFlag):
    acTurnHeight = 0
    acTurns = 1
    acHeight = 2


class AcDynamicBlockReferencePropertyUnitsType(IntFlag):
    acNoUnits = 0
    acAngular = 1
    acDistance = 2
    acArea = 3


class AcPointCloudExStylizationType(IntFlag):
    acRGB = 0
    acObject = 1
    acNormals = 2
    acIntensities = 3
    acElevation = 4
    acClassification = 5


class AcOleType(IntFlag):
    acOTLink = 1
    acOTEmbedded = 2
    acOTStatic = 3


class AcOlePlotQuality(IntFlag):
    acOPQMonochrome = 0
    acOPQLowGraphics = 1
    acOPQHighGraphics = 2


class AcPointCloudIntensityStyle(IntFlag):
    acIntensityGrayscale = 0
    acIntensityRainbow = 1
    acIntensityRed = 2
    acIntensityGreen = 3
    acIntensityBlue = 4
    acIntensityEditableFlag = 5


class AcColorMethod(IntFlag):
    acColorMethodByLayer = 192
    acColorMethodByBlock = 193
    acColorMethodByRGB = 194
    acColorMethodByACI = 195
    acColorMethodForeground = 197


class AcMenuGroupType(IntFlag):
    acBaseMenuGroup = 0
    acPartialMenuGroup = 1


class AcMLeaderContentType(IntFlag):
    acNoneContent = 0
    acBlockContent = 1
    acMTextContent = 2


class AcDrawMLeaderOrderType(IntFlag):
    acDrawContentFirst = 0
    acDrawLeaderFirst = 1


class AcDrawLeaderOrderType(IntFlag):
    acDrawLeaderHeadFirst = 0
    acDrawLeaderTailFirst = 1


class AcSegmentAngleType(IntFlag):
    acDegreesAny = 0
    acDegrees15 = 1
    acDegrees30 = 2
    acDegrees45 = 3
    acDegrees60 = 4
    acDegrees90 = 6
    acDegreesHorz = 12


class AcMLeaderType(IntFlag):
    acStraightLeader = 1
    acSplineLeader = 2
    acInVisibleLeader = 0


class AcTextAttachmentDirection(IntFlag):
    acAttachmentHorizontal = 0
    acAttachmentVertical = 1


class AcTextAttachmentType(IntFlag):
    acAttachmentTopOfTop = 0
    acAttachmentMiddleOfTop = 1
    acAttachmentBottomOfTop = 2
    acAttachmentBottomOfTopLine = 3
    acAttachmentMiddle = 4
    acAttachmentMiddleOfBottom = 5
    acAttachmentBottomOfBottom = 6
    acAttachmentBottomLine = 7
    acAttachmentAllLine = 8


class AcVerticalTextAttachmentType(IntFlag):
    acAttachmentCenter = 0
    acAttachmentLinedCenter = 1


class AcBlockConnectionType(IntFlag):
    acConnectExtents = 0
    acConnectBase = 1


class AcTextAngleType(IntFlag):
    acInsertAngle = 0
    acHorizontalAngle = 1
    acAlwaysRightReadingAngle = 2


class AcTextAlignmentType(IntFlag):
    acLeftAlignment = 0
    acCenterAlignment = 1
    acRightAlignment = 2


class AcAttributeMode(IntFlag):
    acAttributeModeNormal = 0
    acAttributeModeInvisible = 1
    acAttributeModeConstant = 2
    acAttributeModeVerify = 4
    acAttributeModePreset = 8
    acAttributeModeLockPosition = 16
    acAttributeModeMultipleLine = 32


class AcLeaderType(IntFlag):
    acLineNoArrow = 0
    acSplineNoArrow = 1
    acLineWithArrow = 2
    acSplineWithArrow = 3


class AcBlockScaling(IntFlag):
    acAny = 0
    acUniform = 1


class AcSaveAsType(IntFlag):
    acUnknown = -1
    acR12_dxf = 1
    acR13_dwg = 4
    acR13_dxf = 5
    acR14_dwg = 8
    acR14_dxf = 9
    ac2000_dwg = 12
    ac2000_dxf = 13
    ac2000_Template = 14
    ac2004_dwg = 24
    ac2004_dxf = 25
    ac2004_Template = 26
    ac2007_dwg = 36
    ac2007_dxf = 37
    ac2007_Template = 38
    ac2010_dwg = 48
    ac2010_dxf = 49
    ac2010_Template = 50
    ac2013_dwg = 60
    ac2013_dxf = 61
    ac2013_Template = 62
    ac2018_dwg = 64
    ac2018_dxf = 65
    ac2018_Template = 66
    acNative = 64
    acR15_dwg = 12
    acR15_dxf = 13
    acR15_Template = 14
    acR18_dwg = 24
    acR18_dxf = 25
    acR18_Template = 26


class AcMenuFileType(IntFlag):
    acMenuFileCompiled = 0
    acMenuFileSource = 1


class AcPointCloudStylizationType(IntFlag):
    acScanColor = 0
    acObjectColor = 1
    acNormal = 2
    acIntensity = 3


class AcShadePlot(IntFlag):
    acShadePlotAsDisplayed = 0
    acShadePlotWireframe = 1
    acShadePlotHidden = 2
    acShadePlotRendered = 3


class AcKeyboardPriority(IntFlag):
    acKeyboardRunningObjSnap = 0
    acKeyboardEntry = 1
    acKeyboardEntryExceptScripts = 2


class AcEntityName(IntFlag):
    ac3dFace = 1
    ac3dPolyline = 2
    ac3dSolid = 3
    acArc = 4
    acAttribute = 5
    acAttributeReference = 6
    acBlockReference = 7
    acCircle = 8
    acDimAligned = 9
    acDimAngular = 10
    acDimDiametric = 12
    acDimOrdinate = 13
    acDimRadial = 14
    acDimRotated = 15
    acEllipse = 16
    acHatch = 17
    acLeader = 18
    acLine = 19
    acMtext = 21
    acPoint = 22
    acPolyline = 23
    acPolylineLight = 24
    acPolymesh = 25
    acRaster = 26
    acRay = 27
    acRegion = 28
    acShape = 29
    acSolid = 30
    acSpline = 31
    acText = 32
    acTolerance = 33
    acTrace = 34
    acPViewport = 35
    acXline = 36
    acGroup = 37
    acMInsertBlock = 38
    acPolyfaceMesh = 39
    acMLine = 40
    acDim3PointAngular = 41
    acExternalReference = 42
    acTable = 43
    acDimArcLength = 44
    acDimRadialLarge = 45
    acDwfUnderlay = 46
    acDgnUnderlay = 47
    acMLeader = 48
    acSubDMesh = 49
    acPdfUnderlay = 50
    acNurbSurface = 51


class AcAlignmentPointAcquisition(IntFlag):
    acAlignPntAcquisitionAutomatic = 0
    acAlignPntAcquisitionShiftToAcquire = 1


class AcInsertUnitsAction(IntFlag):
    acInsertUnitsPrompt = 0
    acInsertUnitsAutoAssign = 1


class AcPlotPolicy(IntFlag):
    acPolicyNamed = 0
    acPolicyLegacy = 1


class AcDrawingAreaShortCutMenu(IntFlag):
    acNoDrawingAreaShortCutMenu = 0
    acUseDefaultDrawingAreaShortCutMenu = 1


class AcBoolean(IntFlag):
    acFalse = 0
    acTrue = 1


class AcDrawingAreaSCMDefault(IntFlag):
    acRepeatLastCommand = 0
    acSCM = 1


class AcDrawingAreaSCMEdit(IntFlag):
    acEdRepeatLastCommand = 0
    acEdSCM = 1


class AcOnOff(IntFlag):
    acOff = 0
    acOn = 1


class AcPreviewMode(IntFlag):
    acPartialPreview = 0
    acFullPreview = 1


class AcMenuItemType(IntFlag):
    acMenuItem = 0
    acMenuSeparator = 1
    acMenuSubMenu = 2


class AcDrawingAreaSCMCommand(IntFlag):
    acEnter = 0
    acEnableSCMOptions = 1
    acEnableSCM = 2


class AcViewportScale(IntFlag):
    acVpScaleToFit = 0
    acVpCustomScale = 1
    acVp1_1 = 2
    acVp1_2 = 3
    acVp1_4 = 4
    acVp1_5 = 5
    acVp1_8 = 6
    acVp1_10 = 7
    acVp1_16 = 8
    acVp1_20 = 9
    acVp1_30 = 10
    acVp1_40 = 11
    acVp1_50 = 12
    acVp1_100 = 13
    acVp2_1 = 14
    acVp4_1 = 15
    acVp8_1 = 16
    acVp10_1 = 17
    acVp100_1 = 18
    acVp1_128in_1ft = 19
    acVp1_64in_1ft = 20
    acVp1_32in_1ft = 21
    acVp1_16in_1ft = 22
    acVp3_32in_1ft = 23
    acVp1_8in_1ft = 24
    acVp3_16in_1ft = 25
    acVp1_4in_1ft = 26
    acVp3_8in_1ft = 27
    acVp1_2in_1ft = 28
    acVp3_4in_1ft = 29
    acVp1in_1ft = 30
    acVp1and1_2in_1ft = 31
    acVp3in_1ft = 32
    acVp6in_1ft = 33
    acVp1ft_1ft = 34


class AcPredefBlockType(IntFlag):
    acBlockImperial = 0
    acBlockSlot = 1
    acBlockCircle = 2
    acBlockBox = 3
    acBlockHexagon = 4
    acBlockTriangle = 5
    acBlockUserDefined = 6


class AcWindowState(IntFlag):
    acNorm = 1
    acMin = 2
    acMax = 3


class AcPointCloudColorType(IntFlag):
    acTrueColor = 0
    acByColor = 1


class AcMLineJustification(IntFlag):
    acTop = 0
    acZero = 1
    acBottom = 2


class AcLoopType(IntFlag):
    acHatchLoopTypeDefault = 0
    acHatchLoopTypeExternal = 1
    acHatchLoopTypePolyline = 2
    acHatchLoopTypeDerived = 4
    acHatchLoopTypeTextbox = 8


class AcDataLinkUpdateOption(IntFlag):
    acUpdateOptionNone = 0
    acUpdateOptionOverwriteContentModifiedAfterUpdate = 131072
    acUpdateOptionOverwriteFormatModifiedAfterUpdate = 262144
    acUpdateOptionUpdateFullSourceRange = 524288
    acUpdateOptionIncludeXrefs = 1048576


class AcMeshCreaseType(IntFlag):
    acNoneCrease = 0
    acAlwaysCrease = 1
    acCreaseByLevel = 2


class AcDataLinkUpdateDirection(IntFlag):
    acUpdateDataFromSource = 1
    acUpdateSourceFromData = 2


class AcHatchStyle(IntFlag):
    acHatchStyleNormal = 0
    acHatchStyleOuter = 1
    acHatchStyleIgnore = 2


class Ac3DPolylineType(IntFlag):
    acSimple3DPoly = 0
    acQuadSpline3DPoly = 1
    acCubicSpline3DPoly = 2


class AcPolylineType(IntFlag):
    acSimplePoly = 0
    acFitCurvePoly = 1
    acQuadSplinePoly = 2
    acCubicSplinePoly = 3


class AcToolbarDockStatus(IntFlag):
    acToolbarDockTop = 0
    acToolbarDockBottom = 1
    acToolbarDockLeft = 2
    acToolbarDockRight = 3
    acToolbarFloating = 4


class AcTableStyleOverrides(IntFlag):
    acTitleSuppressed = 1
    acHeaderSuppressed = 2
    acFlowDirection = 3
    acHorzCellMargin = 4
    acVertCellMargin = 5
    acTitleRowColor = 6
    acHeaderRowColor = 7
    acDataRowColor = 8
    acTitleRowFillNone = 9
    acHeaderRowFillNone = 10
    acDataRowFillNone = 11
    acTitleRowFillColor = 12
    acHeaderRowFillColor = 13
    acDataRowFillColor = 14
    acTitleRowAlignment = 15
    acHeaderRowAlignment = 16
    acDataRowAlignment = 17
    acTitleRowTextStyle = 18
    acHeaderRowTextStyle = 19
    acDataRowTextStyle = 20
    acTitleRowTextHeight = 21
    acHeaderRowTextHeight = 22
    acDataRowTextHeight = 23
    acTitleRowDataType = 24
    acHeaderRowDataType = 25
    acDataRowDataType = 26
    acTitleHorzTopColor = 40
    acTitleHorzInsideColor = 41
    acTitleHorzBottomColor = 42
    acTitleVertLeftColor = 43
    acTitleVertInsideColor = 44
    acTitleVertRightColor = 45
    acHeaderHorzTopColor = 46
    acHeaderHorzInsideColor = 47
    acHeaderHorzBottomColor = 48
    acHeaderVertLeftColor = 49
    acHeaderVertInsideColor = 50
    acHeaderVertRightColor = 51
    acDataHorzTopColor = 52
    acDataHorzInsideColor = 53
    acDataHorzBottomColor = 54
    acDataVertLeftColor = 55
    acDataVertInsideColor = 56
    acDataVertRightColor = 57
    acTitleHorzTopLineWeight = 70
    acTitleHorzInsideLineWeight = 71
    acTitleHorzBottomLineWeight = 72
    acTitleVertLeftLineWeight = 73
    acTitleVertInsideLineWeight = 74
    acTitleVertRightLineWeight = 75
    acHeaderHorzTopLineWeight = 76
    acHeaderHorzInsideLineWeight = 77
    acHeaderHorzBottomLineWeight = 78
    acHeaderVertLeftLineWeight = 79
    acHeaderVertInsideLineWeight = 80
    acHeaderVertRightLineWeight = 81
    acDataHorzTopLineWeight = 82
    acDataHorzInsideLineWeight = 83
    acDataHorzBottomLineWeight = 84
    acDataVertLeftLineWeight = 85
    acDataVertInsideLineWeight = 86
    acDataVertRightLineWeight = 87
    acTitleHorzTopVisibility = 100
    acTitleHorzInsideVisibility = 101
    acTitleHorzBottomVisibility = 102
    acTitleVertLeftVisibility = 103
    acTitleVertInsideVisibility = 104
    acTitleVertRightVisibility = 105
    acHeaderHorzTopVisibility = 106
    acHeaderHorzInsideVisibility = 107
    acHeaderHorzBottomVisibility = 108
    acHeaderVertLeftVisibility = 109
    acHeaderVertInsideVisibility = 110
    acHeaderVertRightVisibility = 111
    acDataHorzTopVisibility = 112
    acDataHorzInsideVisibility = 113
    acDataHorzBottomVisibility = 114
    acDataVertLeftVisibility = 115
    acDataVertInsideVisibility = 116
    acDataVertRightVisibility = 117
    acCellAlign = 130
    acCellBackgroundFillNone = 131
    acCellBackgroundColor = 132
    acCellContentColor = 133
    acCellTextStyle = 134
    acCellTextHeight = 135
    acCellTopGridColor = 136
    acCellRightGridColor = 137
    acCellBottomGridColor = 138
    acCellLeftGridColor = 139
    acCellTopGridLineWeight = 140
    acCellRightGridLineWeight = 141
    acCellBottomGridLineWeight = 142
    acCellLeftGridLineWeight = 143
    acCellTopVisibility = 144
    acCellRightVisibility = 145
    acCellBottomVisibility = 146
    acCellLeftVisibility = 147
    acCellDataType = 148


class AcViewportSplitType(IntFlag):
    acViewport2Horizontal = 0
    acViewport2Vertical = 1
    acViewport3Left = 2
    acViewport3Right = 3
    acViewport3Horizontal = 4
    acViewport3Vertical = 5
    acViewport3Above = 6
    acViewport3Below = 7
    acViewport4 = 8


ACAD_LWEIGHT = AcLineWeight
ACAD_COLOR = AcColor


__all__ = [
    'IAcadComparedReference', 'AcOnOff', 'AcPlotScale', 'IAcadLine',
    'acSectionSubItemkNone', 'AcadSecurityParams', 'acWhite',
    'acDegrees60', 'acMenuFileSource', 'acAttachmentHorizontal',
    'IAcadSubDMeshVertex', 'acInsertUnitsDecimeters', 'acR18_dxf',
    'acHorizontalAlignmentFit', 'acArrowOpen',
    'acDataVertLeftVisibility', 'kInheritCellFormat', 'acVp1_16',
    'acFirstNormal', 'AcParseOption', 'AcHatchObjectType',
    'acDegreesHorz', 'acAlwaysRightReadingAngle',
    'acDimPrecisionFive', 'ac1_4', 'IAcadSortentsTable',
    'acSectionGenerationDestinationReplaceBlock',
    'AcKeyboardPriority', 'ac2004_dxf', 'acHorzBottom',
    'acPrinterNeverAlert', 'acExtendOtherEntity', 'ac2000_dxf',
    'IAcadViewports', 'acDimPrecisionSix', 'acLnWt009', 'acMLine',
    'AcadDim3PointAngular', 'AcDimFractionType', 'acLnWt053',
    'AcExtendOption', 'acCellContentColor', 'acMetric',
    'acDataVertLeftLineWeight', 'AcadSectionSettings',
    'acNurbSurface', 'acSplineLeader', 'AcCellEdgeMask',
    'acDimLDecimal', 'AcadObject', 'acVp1_8in_1ft', 'acFontBold',
    'acAttachmentTopOfTop', 'acDimArchitectural', 'acCircle',
    'acOTLink', 'acHeaderRowColor', 'AcadPolyfaceMesh',
    'acProxyBoundingBox',
    'acMergeCellStyleConvertDuplicatesToOverrides', 'AcadDictionary',
    'Ac3DPolylineType', 'IAcadLayouts', 'IAcadXline',
    'ac2000_Template', 'acDimDecimal', 'acNoneContent',
    'acArrowIntegral', 'acNotStacked', 'acScale',
    'acDim3PointAngular', 'acPolicyNamed', 'acAllViewports',
    'acHeaderRowAlignment', 'AcadLineType', 'acCyan',
    'IAcadDictionaries', 'IAcadPointCloudEx', 'acDimWindowsDesktop',
    'AcSplineFrameType', 'acDataRowDataType', 'AcadTableStyle',
    'acGroup', 'acDimPrecisionThree', 'acRepeatLastCommand',
    'AcadMLeader', 'acAllCellProperties', 'acCellBackgroundFillNone',
    'acDimLWindowsDesktop', 'acHeaderVertLeftLineWeight',
    'acDrawContentFirst', 'AcDrawingAreaShortCutMenu', 'AcadTable',
    'acScientific', 'acAlignmentBottomRight', 'acCellMarginTop',
    'acInsertUnitsParsecs', 'acCellStateContentLocked',
    'acParseOptionNone', 'acLineSpacingStyleAtLeast', 'AcCellOption',
    'acInsertUnitsAngstroms', 'acDataHorzBottomVisibility',
    'acDegrees180', 'IAcadView', 'acReceivesShadows', 'acSCM',
    'acTitleHorzBottomLineWeight', 'acHorizontalAlignmentLeft',
    'AcadWipeout', 'AcPointCloudStylizationType', 'acTolTop',
    'acArrowOrigin2', 'AcadDimAngular', 'acHatchStyleOuter',
    'ACADSECURITYPARAMS_ENCRYPT_PROPS', 'AcBoolean', 'AcLeaderType',
    'AcadMLine', 'acDimFractional', 'AcPredefBlockType',
    'AcDataLinkUpdateOption', 'IAcadEllipse', 'IAcadArc',
    'acCastsAndReceivesShadows', 'acHatchPatternTypeUserDefined',
    'acDegreesAny', 'acPViewport', 'acTitleVertRightLineWeight',
    'IAcadGroup', 'acLnWt070', 'acAlignmentRight', 'acTolNone',
    'acByBlock', 'IAcadDim3PointAngular', 'AcadSubEntSolidFace',
    'acQuadSplinePoly', 'acBlockImperial', 'acAlignmentMiddleLeft',
    'acDataRow', 'IAcad3DSolid', 'acUseMaximumPrecision',
    'AcPolylineType', 'acHatchLoopTypeDerived', 'acHatch',
    'acAlwaysCrease', 'acHatchPatternTypeCustomDefined', 'ac0degrees',
    'acUpdateOptionIncludeXrefs', 'acDataVertRightVisibility',
    'ac1_20', 'IAcadMaterial', 'acLeftAlignment', 'AcDragDisplayMode',
    'AcMLeaderType',
    'acUpdateOptionOverwriteFormatModifiedAfterUpdate',
    'AcInsertUnitsAction', 'acVp1_100', 'AcadPolygonMesh',
    'IAcadDynamicBlockReferenceProperty', 'ac1_8in_1ft',
    'acSectionType2dSection', 'acSectionState2Boundary',
    'acProxyShow', 'acLineWithArrow', 'acCellRightGridColor',
    'AcUnderlayLayerOverrideType', 'AcSaveAsType', 'AcadPointCloud',
    'acTitleRowFillNone', 'acHeaderVertInsideLineWeight', 'acHide',
    'acUpdateOptionUpdateFullSourceRange', 'acUpdateOptionNone',
    'acDragDisplayAutomatically', 'IAcadTextStyles', 'acTopMask',
    'AcadMaterial', 'acDataHorzInsideColor', 'ACAD_COLOR', 'acVp1_10',
    'acHatchStyleNormal', 'acInsertUnitsMiles', 'AcadDimAligned',
    'IAcadUCSs', 'acCellStateFormatLocked', 'acDegrees090',
    'acDegrees90', 'acLsPlotStyle', 'acTableTopToBottom',
    'acDataVertInsideVisibility', 'AcAngleUnits',
    'acHatchPatternTypePreDefined', 'acFractional', 'IAcadMLeader',
    'AcadPaperSpace', 'acTolMiddle', 'ac3_4in_1ft',
    'acAttachmentMiddle', 'acEdRepeatLastCommand', 'acString',
    'acCenterNone', 'ac2018_dxf', 'acCellStateLinked', 'IAcadLayers',
    'acTolLimits', 'AcadSubEntity', 'acTitleHorzInsideVisibility',
    'acFontBoldItalic', 'IAcadShape', 'acPreDefinedGradient',
    'AcadHyperlink', 'acByLayer', 'acPolicyLegacyQuery',
    'acCellContentTypeValue', 'AcCoordinateSystem', 'AcadTextStyles',
    'acCellAlign', 'acTolBasic', 'IAcadUnderlay',
    'acShadePlotAsDisplayed', 'acCellStateFormatModified',
    'ACAD_DISTANCE', 'acInsertUnitsUSSurveyFeet', 'acTopCenter',
    'acDimLineWithText', 'ACAD_LTYPE', 'acFitCurvePoly',
    'Acad3DPolyline', 'acDimPrecisionOne', 'AcDimArcLengthSymbol',
    'IAcadEntity', 'acColorMethodByRGB', 'acLock', 'AcadView',
    'IAcadRevolvedSurface', 'IAcadMLeaderLeader', 'IAcadGeomapImage',
    'acRightAlignment', 'IAcadDictionary', 'acPaletteBySession',
    'acSqrtChord', 'acXline', 'acPolyfaceMesh', 'acIgnoreMtextFormat',
    'ac3_16in_1ft', 'acHorzInside', 'acTableFlowLeft',
    'acColorMethodByLayer', 'acSectionState2Slice',
    'acSectionSubItemSectionLine', 'AcadSpline', 'acMenuSeparator',
    'IAcadDimRotated', 'AcadBlockReference', 'acDrawLeaderHeadFirst',
    'AcDimUnits', 'ac2007_dxf', 'acCellLeftVisibility',
    'AcadDimRotated', 'AcRegenType', 'acSectionStateVolume',
    'acInsertUnitsMils', 'acSectionSubItemSectionLineTop',
    'acSelectionSetAll', 'IAcadLineTypes', 'acPdfUnderlay',
    'acAlignmentFit', 'AcWireframeType', 'acAlignmentProperty',
    'AcTableFlowDirection', 'acLnWt106', 'acCubicSpline3DPoly',
    'ac2010_dwg', 'acNoOverrides', 'acTitleRow', 'acR13_dwg',
    'acElevation', 'AcadPoint', 'acHeaderVertInsideColor',
    'acInsertUnitsMicroinches', 'acArrowClosedBlank',
    'IAcadMInsertBlock', 'acTextCell', 'ac2007_Template',
    'acTolDeviation', 'acPreferenceClassic', 'acTrace',
    'acPartialPreview', 'AcadSubDMeshVertex', 'acLastNormal',
    'acColorMethodForeground', 'IAcadPointCloudEx2', 'acBlockCircle',
    'acCellContentLayoutStackedHorizontal', 'ac1_128in_1ft',
    'IAcadHyperlink', 'IAxDbDocumentEvents', 'ac1_5',
    'AcSectionState2', 'acOverFirstExtension', 'AcCellContentLayout',
    'acTitleHorzTopLineWeight', 'AcColor', 'AcadDimRadial',
    'acAttachmentPointTopCenter', 'acPrinterAlertOnce',
    'acContentProperties', 'acEnableSCMOptions', 'acUseDraftAngles',
    'acAlignmentBottomLeft', 'acLsOn', 'acSolid', 'acTolerance',
    'IAcadLeader', 'acTrue', 'acSectionSubItemVerticalLineTop',
    'ac2018_Template', 'acAttachmentPointBottomLeft', 'acR13_dxf',
    'AcadSection', 'ac3dPolyline', 'AcDimFit', 'acPaperSpaceDCS',
    'acAutoScale', 'acVp3_8in_1ft', 'ac1_16in_1ft',
    'acHeaderHorzInsideLineWeight', 'acDemanLoadDisable', 'ac3in_1ft',
    'acHeaderHorzTopLineWeight', 'acHeaderRowDataType',
    'acIntensityBlue', 'acHorizontalAlignmentRight', 'IAcadGroups',
    'acInsertAngle', 'AcHorizontalAlignment',
    'AcadSecurityParamsConstants', 'acShow',
    'IAcadSectionTypeSettings', 'acInsertUnitsHectometers',
    'acPixels', 'acVertCellMargin', 'acToolbarDockBottom',
    'acBottomCenter', 'acInsertUnitsMicrons', 'IAcad3DPolyline',
    'acTitleSuppressed', 'acIntensityGrayscale', 'AcadShape',
    'IAcadSubDMesh', 'AcTextAttachmentType', 'acTopToBottom',
    'acHeaderVertRightVisibility', 'AcLineWeight', 'acNoUnits',
    'ACAD_ANGLE', 'acOCS', 'acContentColor', 'acVp2_1',
    'acArrowOblique', 'acFontItalic', 'ac1ft_1ft', 'acLnWt211',
    'IAcadLoftedSurface', 'AcViewportScale', 'acVp1_1', 'acMergeAll',
    'AcCellProperty', 'AcTextAlignmentType',
    'IAcadAttributeReference', 'ACADSECURITYPARAMS_SIGN_DATA',
    'acCCW', 'acDataVertRightLineWeight', 'acLnWt200', 'acUnitless',
    'AcGridLineType', 'acZoomScaledAbsolute',
    'AcPointCloudExStylizationType', 'acDimPrecisionTwo',
    'acVp3_4in_1ft', 'acUnknownCell', 'acDataTypeAndFormat',
    'IAcadSpline', 'acAttributeModeInvisible',
    'acTitleVertRightColor', 'acVp1_5', 'acDemandLoadEnabled',
    'acPolicyLegacy', 'acHeaderRowFillNone',
    'acSectionGenerationDestinationFile', 'acMiddleRight', 'acVp1_2',
    'acHeaderVertRightColor', 'acPenWidth100', 'acUniformParam',
    'acAlignmentMiddleCenter', 'acTitleVertInsideLineWeight',
    'AcDimToleranceMethod', 'acCellStateFormatReadOnly',
    'AcGradientPatternType', 'AcTableStyleOverrides', 'acUnitArea',
    'IAcadDatabase', 'acOQLineArt', 'acPenWidth070',
    'AcPlotPaperUnits', 'AcLayerStateMask', 'AcValueUnitType',
    'acCubicSurfaceMesh', 'acR15_Template', 'acCellRightVisibility',
    'AcCellMargin', 'acMillimeters', 'acInsertUnitsUSSurveyMile',
    'AcadSweptSurface', 'acTitleVertInsideColor', 'IAcadSurface',
    'acAlignmentMiddleRight', 'acVp1_30', 'AcadSortentsTable',
    'acArrowSmall', 'IAcadDimDiametric', 'acTolBottom',
    'acTableFlowRight', 'acEnableSCM', 'IAcadMText',
    'acTitleVertLeftLineWeight', 'acIntensity', 'acArrowNone',
    'IAcadSolid', 'AcadMInsertBlock', 'AcAlignment',
    'AcCellContentType', 'acTitleRowColor', 'AcTextAngleType',
    'IAcadLayer', 'AcadMText', 'acWindow', 'acPolicyLegacyLegacy',
    'acSectionTypeLiveSection', 'acColorMethodByBlock',
    'acTextFlagBackward', 'acViewport3Below', 'ACAD_LWEIGHT',
    'AcadPointCloudEx', 'acGrads', 'acSimplePoly',
    'acCellMarginRight', 'acDataRowTextStyle',
    'acDataHorzBottomLineWeight', 'acFalse', 'acToolbarSeparator',
    'AcadDatabase', 'acSymNone', 'acRightMask',
    'acTitleHorzBottomColor', 'acViewport3Horizontal',
    'acQuadSurfaceMesh', 'IAcadRay', 'acViewport3Vertical',
    'acCellTextHeight', 'AcOlePlotQuality', 'acHeaderRow',
    'acTableSelectWindow', 'ac3dFace', 'acPrinterNeverAlertLogOnce',
    'acArea', 'acUnknown', 'AcadPlaneSurface', 'acArrowDotBlank',
    'acZoomScaledRelative', 'ACAD_NULL', 'AcGridLineStyle',
    'acInsertUnitsCentimeters', 'acSectionType3dSection',
    'AcSplineKnotParameterizationType', 'IAcadDimOrdinate',
    'acUniform', 'acMarginRight', 'acArrowUserDefined',
    'IAcadTableStyle', 'acVp1_20', 'acHatchLoopTypeTextbox',
    'acVp1_50', 'acLnWt140', 'AcPreviewMode', 'acLnWt005',
    'acHeaderHorzTopVisibility', 'acOQGraphics',
    'acDimPrecisionEight', 'acAlignmentAligned', 'ac2010_dxf',
    'acR18_Template', 'acMergeCellStyleIgnoreNewStyles',
    'IAcadTextStyle', 'acForExpression', 'acDimScientific',
    'acCellContentLayoutFlow', 'acTitleVertRightVisibility',
    'acPolicyLegacyDefault', 'acArrowDatumFilled',
    'acColorMethodByACI', 'acVp1_16in_1ft', 'acLsPlot',
    'acInsertUnitsNanometers', 'acHatchLoopTypeDefault',
    'acFontRegular', 'acUnder', 'acAttachmentPointMiddleLeft',
    'acVp1_8', 'acArrowBoxBlank', 'acEnter', 'ac6in_1ft',
    'ACADSECURITYPARAMS_ENCRYPT_DATA', 'acTitleVertInsideVisibility',
    'acTurnHeight', 'acAttachmentBottomOfTop', 'acPenWidth013',
    'AcSectionGeneration', 'acInsertUnitsAstronomicalUnits',
    'acTitleHorzInsideColor', 'AcLineSpacingStyle',
    'acControlVertices', 'acDouble', 'acOPQMonochrome',
    'AcTextFontStyle', 'acVp4_1', 'acLsNone', 'kCellOptionNone',
    'AcadLayer', 'acOQPhoto', 'IAcadObject', 'AcAttributeMode',
    'acDimDiametric', 'acUnitDistance', 'LONG_PTR',
    'acTitleVertLeftColor', 'AcadLayerStateManager',
    'AcadSecurityParamsType', 'ac1in_1ft', 'Acad3DFace',
    'AcadGeoPositionMarker', 'acDataVertInsideLineWeight',
    'acVertInside', 'acHorizontalAngle', 'acInsertUnitsUSSurveyInch',
    'acMInsertBlock', 'AcUnits', 'acFit',
    'acCellStateContentReadOnly', 'AcActiveSpace',
    'AcDimHorizontalJustification', 'acConnectExtents', 'IAcadMLine',
    'acCellMarginHorzSpacing', 'acPolylineLight', 'acBlockSlot',
    'ACADSECURITYPARAMS_ADD_TIMESTAMP', 'ac3_8in_1ft', 'acPolymesh',
    'acLnWt050', 'acHeaderHorzInsideColor', 'acExtendThisEntity',
    'AcadDimStyle', 'ac2013_dwg', 'AcadSurface',
    'acInvalidCellProperty', 'acSectionStatePlane', 'acDataType',
    'acYellow', 'acCellTopGridColor', 'acAny', 'AcAttachmentPoint',
    'acTableFlowDownOrUp', 'acTable', 'acBlockBox', 'acLnWt120',
    'acVp1_128in_1ft', 'acAbove', 'acResbuf', 'acVp3in_1ft',
    'AcVerticalAlignment', 'acSectionState2Volume',
    'acInsertUnitsAutoAssign', 'acOTEmbedded',
    'acVerticalAlignmentBaseline', 'acVertLeft', 'acSplineNoArrow',
    'acSelectionSetPrevious', 'acConnectBase', 'acLnWt020',
    'acCellTopGridLineWeight', 'acApplied', 'acPolicyNewDefault',
    'acDataHorzBottomColor', 'acDimArcLength', 'acVp1_4in_1ft',
    'acHeaderVertLeftVisibility', 'AcTableDirection',
    'acInsertUnitsYards', 'acHeaderRowTextStyle',
    'acInsertUnitsLightYears', 'AcDimVerticalJustification',
    'ac1_64in_1ft', 'typelib_path', 'acTitleHorzInsideLineWeight',
    'acScaleToFit', 'acTitleVertLeftVisibility',
    'AcadDynamicBlockReferenceProperty', 'IAcadMLeaderStyle',
    'acSectionGenerationDestinationNewBlock', 'acArrowDot', 'acShape',
    'AcLoopType', 'acAlignPntAcquisitionAutomatic', 'acMiddleCenter',
    'acCellBottomVisibility', 'acExtents', 'AcadNurbSurface',
    'acDataRowTextHeight', 'acEngineering', 'acDisplay',
    'AcadDwfUnderlay', 'acAttachmentPointTopRight', 'ac2_1',
    'acVp3_32in_1ft', 'AcZoomScaleType', 'acTitleRowAlignment',
    'acR14_dwg', 'acArrowOpen90', 'IAcadBlocks', 'acFlowDirection',
    'acAttachmentAllLine', 'AcOleType', 'IAcadSubEntSolidFace',
    'acHeaderHorzBottomColor', 'acLeftMask', 'AcadPolyline',
    'acUnitVolume', 'acNoDrawingAreaShortCutMenu', 'acViewport3Above',
    'acR18_dwg', 'AcadPViewport', 'acDate', 'ac2010_Template',
    'ac2018_dwg', 'IAcadSectionSettings', 'AcadTolerance',
    'IAcadExternalReference', 'acCellStateContentModified',
    'AcMeshCreaseType', 'acTextStyle', 'acMenuItem', 'acZero',
    'IAcadMaterials', 'AcMenuFileType', 'AcadSectionTypeSettings',
    'acActiveViewport', 'AcadSubEntSolidEdge', 'AcARXDemandLoad',
    'acOverSecondExtension', 'acSectionSubItemBackLineTop',
    'acInvalidGridLine', 'acDataRowFillNone', 'acVp10_1',
    'acSectionSubItemSectionLineBottom', 'acBottomRight',
    'acHatchObject', 'acTop', 'AcadPlotConfigurations',
    'acAttachmentLinedCenter', 'acPenWidthUnk', 'acMTextContent',
    'acArrowDotSmall', 'acSectionStateBoundary', 'acArrowClosed',
    'AcadText', 'IAcadDwfUnderlay', 'AcadSubEntSolidVertex',
    'AcSplineMethodType', 'acZoomScaledRelativePSpace',
    'AcadLoftedSurface', 'acKeyboardEntryExceptScripts',
    'AcadHyperlinks', 'AcDimArrowheadType', 'acHeaderRowFillColor',
    'acCellStateNone', 'IAcadLWPolyline', 'acStraightLeader',
    'acLimits', 'acAttachmentMiddleOfBottom',
    'acSectionGenerationSourceSelectedObjects',
    'acSectionState2Plane', 'acLnWt040', 'acVp3_16in_1ft', 'acOn',
    'IAcadTolerance', 'AcadRegisteredApplication', 'acDimLFractional',
    'acHatchLoopTypeExternal', 'acMoveTextNoLeader',
    'acViewport2Horizontal', 'AcadTextStyle', 'acInsertUnitsInches',
    'ac1_16', 'acSymAbove', 'acArrowsOnly', 'acToolbarDockTop',
    'acBlockContent', 'acRuled', 'AcDrawLeaderOrderType',
    'acCellDataType', 'acIntensities', 'acDataHorzInsideVisibility',
    'AcadOle', 'IAcadDimStyles', 'IAxDbDocument', 'acCenterMark',
    'IAcadRasterImage', 'AcOleQuality', 'acOutside', 'AcadUCSs',
    'acProxyNotShow', 'acBestFit', 'ac270degrees', 'AcSectionSubItem',
    'acPenWidth050', 'AxDbDocument', 'acBlockCell', 'acContentLayout',
    'AcadEllipse', 'acTableSelectCrossing', 'AcSelectType',
    'acHorizontalAlignmentAligned', 'acOPQHighGraphics',
    'acCellContentTypeBlock', 'AcadLine', 'acAttributeModeVerify',
    'acAlignmentMiddle', 'acLineSpacingStyleExactly', 'acLeader',
    'acToolbarFlyout', 'acR15_dxf', 'acSimpleMesh', 'acBlockHexagon',
    'AcadIdPair', 'acLong', 'AcViewportSplitType',
    'acAlignPntAcquisitionShiftToAcquire', 'ac1_32in_1ft',
    'acIntensityRainbow', 'acHeaderVertRightLineWeight', 'acTextOnly',
    'acDimLArchitectural', 'acHorzCellMargin', 'acObjectColor',
    'acAttributeModeMultipleLine', 'acR15_dwg', 'AcadSubDMeshFace',
    'acView', 'acGeneral', 'acMax', 'AcPointCloudColorType',
    'acDataRowAlignment', 'acLineNoArrow', 'IAcadPoint',
    'IAcadIdPair', 'acCellTextStyle', 'AcadAttribute',
    'acAttachmentBottomLine', 'IAcadRegion', 'acIsoparms',
    'AcProxyImage', 'acToolbarDockRight', 'acBottomLeft', 'acJIS',
    'acLsColor', 'acMarginLeft', 'acLsLocked', 'acDimAligned',
    'acRGB', 'ACAD_NOUNITS', 'acDegreeMinuteSeconds', 'acNorm',
    'AcadDgnUnderlay', 'AcadDimDiametric',
    'acSectionSubItemBackLineBottom', 'IAcadTable',
    'IAcadGeoPositionMarker', 'IAcadSubDMeshEdge',
    'acDemandLoadEnabledWithCopy', 'IAcadDimArcLength',
    'AcXRefDemandLoad', 'acHorizontalAlignmentMiddle',
    'acDemandLoadDisabled', 'acAttributeModePreset', 'IAcadSection',
    'acAttributeReference', 'acBackgroundColor', 'AcPlotRotation',
    'acPaperSpace', 'acSelectionSetCrossingPolygon', 'acHorzCentered',
    'acMtext', 'AcCellAlignment', 'acBuffer', 'acModelSpace',
    'acAttributeModeConstant', 'acHatchLoopTypePolyline',
    'AcadDimension', 'IAcadDimRadialLarge', 'AcDrawMLeaderOrderType',
    'acTitleRowDataType', 'acArrowDefault', 'acDrawLeaderTailFirst',
    'acArrowBoxFilled', 'acKeyboardRunningObjSnap', 'IAcadText',
    'AcPolymeshType', 'acRadians', 'acPoint', 'IAcadSubEntSolidEdge',
    'acTitleRowFillColor', 'AcadBlock', 'AcDimTextMovement',
    'acMiddleLeft', 'acSelectionSetWindow',
    'acVerticalAlignmentBottom', 'acViewport3Left',
    'acCenterAlignment', 'acLnWt035', 'AcSelect', 'acBottom',
    'acDimOrdinate', 'acAttachmentBottomOfTopLine', 'acNormal',
    'acHorizontalAlignmentCenter', 'IAcadSection2', 'acSymInFront',
    'acAttributeModeNormal', 'acTextHeight',
    'acSectionGenerationSourceAllObjects', 'AcadMaterials',
    'ac2004_Template', 'AcToolbarItemType', 'acUnknownDataType',
    'ac2013_dxf', 'acPenWidth200', 'acLsLineWeight', 'acLnWt018',
    'acPenWidth018', 'AcadBlocks', 'acDataRowColor', 'acCastsShadows',
    'AcadXRecord', 'acMarginTop', 'acInsertUnitsDecameters', 'acLine',
    'IAcadHatch', 'acAttributeModeLockPosition',
    'IAcadSectionTypeSettings2', 'acDiagonal', 'acDimEngineering',
    'acIsolines', 'AcadSolid', 'ac2000_dwg', 'IAcadModelSpace',
    'acRed', 'acVerticalAlignmentMiddle', 'AcWindowState', 'acVp1_40',
    'ac1_8', 'ac100_1', 'AcadXline', 'acCreaseByLevel',
    'acDataVertLeftColor', 'acDistance', 'AcKeyboardAccelerator',
    'acIntensityGreen', 'acHeaderVertInsideVisibility',
    'IAcadLayerStateManager', 'ac3_32in_1ft',
    'acAlignmentBottomCenter', 'acGreen', 'ac1_1', 'acPenWidth025',
    'acShadePlotWireframe', 'acAttachmentPointMiddleCenter',
    'acObject', 'IAcadSubEntSolidVertex', 'AcadSubDMesh',
    'acDataHorzTopVisibility', 'AcadMLeaderStyle',
    'acAttachmentPointBottomCenter', 'AcadHatch', 'acVp1ft_1ft',
    'acLsLineType', 'acUnitAngle', 'AcBlockScaling', 'acDegrees000',
    'acObjectId', 'IAcadPolyfaceMesh', 'acDataRowFillColor',
    'acTitleHorzTopColor', 'acInsertUnitsFeet', 'IAcadUCS',
    'acVp1_2in_1ft', 'acLnWt060', 'AcadGeomapImage', 'acDimRadial',
    'acDegrees45', 'IAcadLineType', 'acDataHorzInsideLineWeight',
    'AcToolbarDockStatus', 'acPlotOrientationLandscape',
    'acPreserveMtextFormat', 'acLnWt090', 'ac2013_Template',
    'acInVisibleLeader', 'acViewport3Right',
    'AcLoftedSurfaceNormalType', 'AcadRegisteredApplications',
    'ac3dSolid', 'AcadLineTypes', 'AcBooleanType', 'acBottomToTop',
    'acVp1and1_2in_1ft', 'acSelectionSetCrossing', 'IAcadSummaryInfo',
    'AcDrawingDirection', 'acDimRadialLarge', 'acPenWidth140',
    'AcLoadPalette', 'AcDimCenterType', 'AcShadowDisplayType',
    'acDimRotated', 'acUseDefaultDrawingAreaShortCutMenu',
    'acUpdateOptionOverwriteContentModifiedAfterUpdate',
    'IAcadPolygonMesh', 'AcadComparedReference',
    'acBezierSurfaceMesh', 'AcadDimArcLength', 'acExternalReference',
    'ac8_1', 'acR12_dxf', 'acDataHorzTopLineWeight',
    'acInsertUnitsUnitless', 'acSelectionSetLast',
    'acUpdateSourceFromData', 'acAttribute', 'acDisplayDCS',
    'acHeight', 'acSmooth', 'AcadLayout', 'AcCellType',
    'acBaseMenuGroup', 'AcPlotPolicyForLegacyDwgs', 'acHorzTop',
    'acViewport2Vertical', 'acPartialMenuGroup',
    'acEnableBackgroundColor', 'acSectionSubItemBackLine',
    'acQuadSpline3DPoly', 'acCellBackgroundColor', 'ac1_10',
    'AcTextGenerationFlag', 'acTurns', 'kFormatOptionNone',
    'acVp1_64in_1ft', 'AcHelixConstrainType', 'acIgnoreShadows',
    'ac180degrees', 'acArc', 'AcMenuGroupType',
    'acAttachmentPointMiddleRight', 'acScanColor', 'IAcadPViewport',
    'acDataVertInsideColor', 'IAcadDimension', 'acVp1in_1ft',
    'acUpdateDataFromSource', 'acArrowArchTick', 'AcadEntity',
    'acAllNormal', 'AcadArc', 'acRegion', 'AcRowType',
    'acVerticalAlignmentTop', 'acSpline', 'acIntersection',
    'AcDrawingAreaSCMCommand', 'acLnWt013', 'AcMergeCellStyleOption',
    'acDimPrecisionFour', 'IAcadShadowDisplay',
    'acAttachmentPointBottomRight', 'AcadDimStyles', 'AcadAcCmColor',
    'acDegrees30', 'IAcadHelix', 'AcadCircle', 'acLnWtByLayer',
    'acDegrees15', 'acHeaderHorzInsideVisibility',
    'acTextFlagUpsideDown', 'acCellContentTypeField', 'acLsAll',
    'acSimple3DPoly', 'acSetDefaultFormat', 'acTextAndArrows',
    'AcHelixTwistType', 'acLeftToRight', 'acLnWt100', 'acPoint3d',
    'acTrueColor', 'acInsertUnitsMeters', 'acEdSCM',
    'acDegreesUnknown', 'IAcadNurbSurface',
    'IAcadRegisteredApplications', 'IAcadOle',
    'acCellContentLayoutStackedVertical', 'AcISOPenWidth',
    'acVp6in_1ft', 'acExtendNone', 'AcMLineJustification', 'acText',
    'AcSectionState', 'acShadePlotRendered', 'AcadViewport', 'acUCS',
    'AcadExternalReference', 'acFlowDirBtoT', 'IAcadPolyline',
    'AcInsertUnits', 'acSelectionSetFence', 'AcMenuItemType',
    'AcShadePlot', 'IAcadXRecord', 'acAlignmentCenter', 'acDegrees',
    'acAngular', 'acCenterLine', 'AcEntityName', 'acArrowDatumBlank',
    'AcPrinterSpoolAlert', 'AcadSubDMeshEdge', 'acNormals',
    'acMenuFileCompiled', 'acMenuSubMenu', 'acMin',
    'acCellMarginLeft', 'IAcadSubEntity', 'acGridLineStyleSingle',
    'acDegrees270', 'IAcadHyperlinks', 'acEnglish',
    'IAcadSweptSurface', 'AcDynamicBlockReferencePropertyUnitsType',
    'acLnWt158', 'acAttachmentVertical', 'acSecondExtensionLine',
    'acTitleRowTextStyle', 'ac1_30', 'acCellMarginBottom',
    'AcTextAttachmentDirection', 'acHeaderRowTextHeight',
    'IAcad3DFace', 'IAcadViewport', 'acSplineWithArrow',
    'acLnWtByLwDefault', 'acLnWt030', 'acInsertUnitsPrompt',
    'acHeaderHorzBottomVisibility', 'AcadLeader', 'acPoint2d',
    'IAcadBlock', 'acShadePlotHidden', 'acSelectionSetWindowPolygon',
    'acBlockReference', 'acDragDisplayOnRequest', 'acMLeader',
    'ac1_2in_1ft', 'IAcadSectionManager', 'AcadMLeaderLeader',
    'acCellContentTypeUnknown', 'AcadModelSpace', 'AcadDictionaries',
    'AcDrawingAreaSCMEdit', 'acPreferenceCustom', 'IAcadAttribute',
    'acBlockTriangle', 'acViewport4', 'acUserDefinedGradient',
    'AcadLayouts', 'acNoneCrease', 'IAcadPlaneSurface', 'ac1_100',
    'acClassification', 'IAcadSubEntSolidNode', 'acChord',
    'acToolbarButton', 'AcMLeaderContentType', 'AcadViewports',
    'acVpCustomScale', 'acToolbarFloating', 'AcadRasterImage',
    'AcPointCloudIntensityStyle', 'ac1_4in_1ft', 'acDimLEngineering',
    'acTitleHorzBottomVisibility', 'AcadLWPolyline', 'acLnWt025',
    'IAcadPlotConfiguration', 'acOQHighPhoto',
    'AcAlignmentPointAcquisition', 'ac1_2', 'acCellMarginVertSpacing',
    'IAcadDimAligned', 'acInsertUnitsUSSurveyYard', 'AcadUCS',
    'acTopRight', 'acGridLineStyleDouble', 'acIntensityRed',
    'acMergeCellStyleOverwriteDuplicates', 'AcadSectionManager',
    'acHeaderHorzBottomLineWeight', 'acVp8_1', 'acSubtraction',
    'IAcadDimRadial', 'acVertCentered', 'acPlotOrientationPortrait',
    'acDimPrecisionZero', 'acInches', 'IAcadPaperSpace', 'acRaster',
    'acDrawLeaderFirst', 'acAttachmentMiddleOfTop',
    'acDragDoNotDisplay', 'acCellBottomGridLineWeight', 'AcadRay',
    'AcadPdfUnderlay', 'acDemandLoadOnObjectDetect',
    'acBlockUserDefined', 'AcPlotOrientation', 'acNative',
    'acRightToLeft', 'acHorizontal', 'acSubDMesh', 'IAcadWipeout',
    'acEndsNormal', 'ac90degrees', 'AcVerticalTextAttachmentType',
    'Library', 'acDimFractionalStacked', 'acRay',
    'acDimArchitecturalStacked', 'acHeaderHorzTopColor',
    'AcMeasurementUnits', 'AcDrawingAreaSCMDefault', 'acBottomMask',
    'ac10_1', 'acMergeCellStyleCopyDuplicates', 'acPenWidth035',
    'acLsNewViewport', 'acLnWt015', 'AcadGroups',
    'acDataVertRightColor', 'acCellRightGridLineWeight',
    'acCellBottomGridColor', 'ac1_50', 'IAcadPlotConfigurations',
    'acDgnUnderlay', 'AcadTrace', 'Acad3DSolid', 'acOTStatic',
    'AcSegmentAngleType', 'IAcadLayout', 'AcCellState',
    'acAlignmentTopRight', 'acEllipse', 'acTitleRowTextHeight',
    'ac2007_dwg', 'acArchitectural', 'AcadDatabasePreferences',
    'acVp1_4', 'IAcadObjectEvents', 'AcadAttributeReference',
    'acLnWtByBlock', 'acVp1_32in_1ft', 'acTitleHorzTopVisibility',
    'ac4_1', 'acHatchStyleIgnore', 'IAcadRegisteredApplication',
    'AcHatchStyle', 'acRotation', 'AcPlotPolicy',
    'AcBlockConnectionType', 'AcadRevolvedSurface',
    'acOPQLowGraphics', 'AcColorMethod', 'acInsertUnitsGigameters',
    'AcadDimOrdinate', 'acDimAngular', 'ac1_40', 'AcSectionType',
    'acLayout', 'acVertRight', 'acArrowOrigin', 'acCellTopVisibility',
    'AcadViews', 'acCustomParameterization', 'IAcadBlockReference',
    'acCW', 'AcDimLUnits', 'acTopLeft', 'AcPatternType',
    'acBitProperties', 'acDimPrecisionSeven', 'acVpScaleToFit',
    'AcadRegion', 'acAttachmentPointTopLeft', 'IAcadViews',
    'AcPlotPolicyForNewDwgs', 'acGradientObject', 'AcRotationAngle',
    'ACAD_POINT', 'acUnknownRow', 'acMagenta', 'acTolSymmetrical',
    'acDwfUnderlay', 'AcadSummaryInfo',
    'acSectionSubItemVerticalLineBottom', 'AcadLayers', 'AcadHelix',
    'acLsFrozen', 'acPolyline', 'acExtendBoth',
    'AcadPlotConfiguration', 'acArrowOpen30', 'acToolbarDockLeft',
    'IAcadDimStyle', 'IAcadSubDMeshFace', 'IAcadAcCmColor',
    'AcDimPrecision', 'acTableBottomToTop', 'AcadSubEntSolidNode',
    'IAcadDimAngular', 'acMergeCellStyleNone', 'acBlue',
    'acHeaderVertLeftColor', 'acCubicSplinePoly', 'acLnWt000',
    'IAcadCircle', 'acForEditing', 'acInsertUnitsKilometers',
    'IAcadTrace', 'ACADSECURITYPARAMS_ALGID_RC4',
    'acCellLeftGridColor', 'acKeyboardEntry', 'acOff',
    'acHeaderSuppressed', 'acDefaultUnits', 'acAlignmentTopLeft',
    'AcDataLinkUpdateDirection', 'ACAD_LAYER',
    'AcDimToleranceJustify', 'ac2004_dwg', 'acAlignmentLeft',
    'acAlignmentTopCenter', 'acByColor', 'AcValueDataType',
    'acPolicyNewLegacy', 'IAcadPointCloud', 'AcadExtrudedSurface',
    'acDecimal', 'acIntensityEditableFlag', 'acLnWt080',
    'IAcadExtrudedSurface', 'AcPlotType', 'acMarginBottom',
    'acVp100_1', 'IAcadSecurityParams', 'AcadDimRadialLarge',
    'acOQText', 'acCellLeftGridLineWeight', 'acDimLScientific',
    'acPrinterAlwaysAlert', 'acFirstExtensionLine',
    'acMoveTextAddLeader', 'acToolbarControl', 'acR14_dxf',
    'acAttachmentBottomOfBottom', 'AcFormatOption', 'acFullPreview',
    'acInsertUnitsMillimeters', 'acByStyle', 'acUnion',
    'acPaletteByDrawing', 'acWorld', 'acAttachmentCenter',
    'acDemandLoadCmdInvoke', 'acDataFormat',
    'IAcadDatabasePreferences', 'AcadGroup', 'acDataHorzTopColor'
]

