let currentImage = null;
// crear un elemento de menú contextual
let contextMenu = document.createElement("div");
contextMenu.id = "context-menu";
contextMenu.innerHTML = `
<style>
button[c] {
    border: none;
    background-color: transparent;
    text-align: left;
}
button[c]:hover {
    background-color:rgb(16, 187, 30);
    color: white;
}
</style>
    <button c style="display:block;width:100%;" onclick="rotateImage()">Rotar 90°</button>
    <button c style="display:block;width:100%;" onclick="openImage()">Abrir imagen</button>
    <button c style="display:block;width:100%;" onclick="copyUrl()">Copiar URL</button>
    `
contextMenu.style.display = "none";
contextMenu.style.position = "absolute";
contextMenu.style.zIndex = "1000";
contextMenu.style.backgroundColor = "white";
contextMenu.style.border = "0px solid black";
contextMenu.style.padding = "0px";
contextMenu.style.boxShadow = "2px 2px 5px rgba(0, 0, 0, 0.3)";
contextMenu.style.borderRadius = "3px";
document.body.appendChild(contextMenu);

//const contextMenu = document.getElementById("context-menu");

Array.from(document.querySelectorAll("img")).forEach(img => {
    img.addEventListener("contextmenu", function(event) {
        /*event.preventDefault();
        currentImage = event.target;
        contextMenu.style.left = `${event.pageX}px`;
        contextMenu.style.top = `${event.pageY}px`;
        contextMenu.style.display = "block";*/
    });
});

document.addEventListener("click", function() {
    contextMenu.style.display = "none";
});

function rotateImage() {
    if (currentImage) {
        let rotation = currentImage.dataset.rotation ? parseInt(currentImage.dataset.rotation) : 0;
        rotation += 90;
        currentImage.style.transform = `rotate(${rotation}deg)`;
        currentImage.dataset.rotation = rotation;
    }
    contextMenu.style.display = "none";
}

function copyUrl() {
    if (currentImage) {
        alert(currentImage.src);
        navigator.clipboard.writeText(currentImage.src);
    }
    contextMenu.style.display = "none";
}
function openImage() {
    try {
        if (currentImage) {
            window.open(currentImage.src, "_blank");
        }
        contextMenu.style.display = "none";
    } catch (error) {
        alert(error);
    }
    
}



class ImageZoomPan {
    constructor(element) {
        // Guarda el elemento en una variable
        this.element = element;
        // Obtiene el valor de escala actual del elemento
        this.scale = this.getScale()[0];
        // Inicializa las variables de posición inicial y desplazamiento
        this.startX = 0;
        this.startY = 0;
        this.offsetX = this.getTranslate()[0];
        this.offsetY = this.getTranslate()[1];
        // Inicializa la variable de arrastre
        this.dragging = false;
        // Inicializa la variable de posición inicial del ratón
        this.startXY = {};

        // Estilos iniciales
        // Establece el origen de la transformación en la esquina superior izquierda
        this.element.style.transformOrigin = "top left";
        // Establece el cursor a "grab"
        this.element.style.cursor = "grab";

        // Eventos
        // Añade un evento de rueda para hacer zoom
        this.element.addEventListener("wheel", (e) => this.zoom(e));
        // Añade un evento de pulsación de ratón para arrastrar
        this.element.addEventListener("mousedown", (e) => this.startPan(e));
        // Añade un evento de movimiento de ratón para arrastrar
        this.element.addEventListener("mousemove", (e) => this.pan(e));
        // Añade un evento de liberación de ratón para arrastrar
        this.element.addEventListener("mouseup", () => this.endPan());
        // Añade un evento de salida de ratón para arrastrar
        this.element.addEventListener("mouseleave", () => this.endPan());
        // Añade un evento de clic para evitar el comportamiento por defecto
        this.element.onclick = e => {
            e.preventDefault();
            let x = e.clientX, y = e.clientY;
            if (this.startXY.x != x || this.startXY.y != y) {
                e.preventDefault();
            }
        }
        // Añade un evento de doble clic para resetear la imagen
        this.element.ondblclick = e => {
            e.preventDefault()
            this.reset();
        };
    }

    reset(){
        // Resetea la transformación de la imagen
        this.element.style.transform = `scale(1) translate(0px, 0px)`;    
        // Establece la escala a 1
        this.scale = 1;
        // Obtiene el desplazamiento actual
        this.offsetX = this.getTranslate()[0];
        this.offsetY = this.getTranslate()[1];
    }

    zoom(event) {
        // Evita el comportamiento por defecto del evento
        event.preventDefault();
        console.log("zoom");
        
        // Establece la cantidad de zoom
        const scaleAmount = 0.7;
        // Calcula la nueva escala
        const newScale = this.scale + (event.deltaY < 0 ? scaleAmount : -scaleAmount);
        
        // Comprueba que la nueva escala esté dentro de los límites
        if (newScale > 0.1 && newScale < 50) { // Limita el zoom entre 0.2x y 5x
            // Obtiene la posición del ratón en relación al elemento
            const rect = this.element.getBoundingClientRect();
            const offsetX = (event.clientX - rect.left) / this.scale;
            const offsetY = (event.clientY - rect.top) / this.scale;

            // Actualiza la escala y el desplazamiento
            this.scale = newScale;
            this.offsetX -= offsetX * scaleAmount * (event.deltaY < 0 ? 1 : -1);
            this.offsetY -= offsetY * scaleAmount * (event.deltaY < 0 ? 1 : -1);

            // Actualiza la transformación
            this.updateTransform();
        }
    }

    startPan(event) {
        // Evita el comportamiento por defecto del evento
        event.preventDefault()
        console.log({x: event.clientX, y: event.clientY});
        // Guarda la posición inicial del ratón
        this.startXY = {x: event.clientX, y: event.clientY};
        
        // Establece la variable de arrastre a true
        this.dragging = true;
        // Guarda la posición inicial del ratón en relación al elemento
        this.startX = event.clientX - this.offsetX;
        this.startY = event.clientY - this.offsetY;
        // Cambia el cursor a "grabbing"
        this.element.style.cursor = "grabbing";
        //document.getElementById("h2").textContent = `scale(${this.scale}) translate(${this.offsetX / this.scale}px, ${this.offsetY / this.scale}px)`
    }

    pan(event) {
        // Si se está arrastrando
        if (this.dragging) {
            // Actualiza el desplazamiento
            //this.offsetX = event.clientX - this.startX;
            //this.offsetY = event.clientY - this.startY;
            this.offsetX = event.clientX - this.startX;
            this.offsetY = event.clientY - this.startY;
            // Actualiza la transformación
            this.updateTransform();
        }
    }

    endPan() {
        //console.log("endPan");
        // Establece la variable de arrastre a false
        this.dragging = false;
        this.element.style.cursor = "grab";
    }

    updateTransform() {
        //let t = `scale(${this.scale}) translate(${this.offsetX / this.scale}px, ${this.offsetY / this.scale}px)`;
        this.element.style.transform = `scale(${this.scale}) translate(${this.offsetX / this.scale}px, ${this.offsetY / this.scale}px)`;
        //console.log(t);
    }


    getTranslate() {
        // Obtiene el estilo computado
        let estilo = window.getComputedStyle(this.element);
        // Extrae el valor de la propiedad transform
        let transform = estilo.transform;
        // Verifica si la transformación está aplicada
        if (transform !== "none") {
            // Extrae los valores de la matriz de transformación
            let valores = transform.match(/matrix.*\((.+)\)/)[1].split(", ");
            let translateX = parseFloat(valores[4]); // El quinto valor en la matriz es translateX
            let translateY = parseFloat(valores[5]); // El quinto valor en la matriz es translateX
            //console.log("translateX:", translateX);
            return [translateX, translateY]
        } else {
            //console.log("No hay ninguna transformación aplicada");
            return [0,0];
        }
    }

    getScale(){
        // Obtiene el estilo computado
        const estilo = window.getComputedStyle(this.element);
        // Extrae el valor de la propiedad transform
        const transform = estilo.transform;
        if (transform !== "none") {
            // Extrae los valores de la matriz de transformación
            const valores = transform.match(/matrix.*\((.+)\)/)[1].split(", ");
            const scaleX = parseFloat(valores[0]); // El primer valor es scaleX
            const scaleY = parseFloat(valores[3]); // El cuarto valor es scaleY
            return [scaleX, scaleY];
        } else {
            return [1,1];
        }

    }
}


try {
    //var imgs = document.querySelectorAll(".panzoom") panzoom
    var imgs_pans = document.querySelectorAll("[panzoom]")
    //var imgs_tags = document.querySelectorAll("img")
    //var imgs = [...Array.from(imgs_pans), ...Array.from(imgs_tags)];
    var imgs = imgs_pans
    // recorrer todas las imagenes
    for (var i = 0; i < imgs.length; i++) {
        var element = imgs[i]
        if (element.hasAttribute("nopanzoom")) {
            // Si tiene nopanzoom no hacer nada
        } else {
            element.ondrop = e => e.preventDefault();
            var a  = new ImageZoomPan(element);
        }
    }    
} catch  (e){
    alert("Error: "+e.line+": "+e)
}
